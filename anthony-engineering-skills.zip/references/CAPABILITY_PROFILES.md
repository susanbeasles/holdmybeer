# Recommended Capability Profiles

These profiles are intentionally asymmetric: broad inspection, narrow mutation.

## Blair Witch Triage

Allow:
- `repo.status`, `repo.primaryBranch`, `repo.resolve`, `repo.refs`;
- `repo.log`, `repo.commit`, `repo.parents`, `repo.ancestors`, `repo.mergeBase`;
- `repo.blame`, `repo.blameTrace`, `repo.fileHistory`, `repo.lastChange`;
- `repo.diff`, `repo.diffTree`, `repo.tree`, bounded `repo.blob`;
- `repo.patchId`, `repo.equivalentChanges`;
- PR inspection and ephemeral analysis.

Deny all publication by default.

## Merge Conflict Therapist

Allow all targeted history inspection plus:
- `repo.analysisWorkspace`;
- `repo.simulateMerge`;
- `repo.conflictDetails`;
- `repo.applyPatchEphemeral`;
- `repo.replaySeriesEphemeral`;
- `repo.testResolutionEphemeral`.

Optionally allow `repo.applyResolvedConflict` and owned-branch commit/publication only for an explicitly authorized resolver workflow.

## Minecraft Steve History Excavator

Allow deep read-only history/object access:
- ancestry, file history, blame tracing, rename/copy detection;
- deleted path history;
- patch IDs and equivalent-change analysis;
- bounded unreachable-object inspection when task requires it.

Deny workspace mutation and publication.

## History Reconstructor Archaeologist

Allow the richest forensic read profile:
- raw commit metadata;
- refs/reflogs/ref history;
- signature/tag verification;
- identity evidence;
- provider audit events;
- reachability and dangling objects;
- PR timelines and CI provenance.

Deny all mutations unless a separate remediation role is explicitly granted.

## Race Condition Drag Racer

Repository reads as needed plus execution/test capabilities:
- run targeted tests repeatedly;
- spawn bounded concurrent local processes;
- create disposable local test artifacts;
- capture traces/logs;
- use ephemeral containers/workspaces when available.

No additional Git publication rights are needed.

## Context Cartographer

Allow:
- read Jira issues, epics, comments, links and status/history;
- read Confluence pages and version metadata;
- read ADR/RFC/design artifacts;
- repository code, tests, schemas and configuration inspection;
- bounded Git history, blame, diff, rename and merge ancestry inspection;
- stable-link generation for evidence.

Deny by default:
- editing Jira/Confluence;
- repository publication/mutation;
- changing issue status or acceptance criteria while reconstructing context.

## Frontend UX Specialist

Allow:
- source/design-system/test inspection;
- frontend build/test/static-analysis commands in isolated workspace;
- browser/performance/accessibility diagnostics when available;
- read-only product context.

Mutation should be granted only when the role is explicitly implementing an approved option.

## Backend UX Specialist

Allow:
- API/schema/client/service/test inspection;
- OpenAPI/GraphQL/proto analysis;
- isolated contract/load/error-path tests;
- read-only telemetry/query access where policy permits.

Do not grant production write access merely to evaluate a contract.

## High-Pressure DX Architect

Allow:
- repository-wide read inspection;
- dependency/build/CI/config analysis;
- bounded architecture metrics and benchmark execution;
- Jira/Confluence/ADR historical reads;
- code generation or isolated reference-slice experiments only when explicitly authorized.

Architecture advice does not imply repository mutation authority.

## Data Model Specialist

Allow:
- schema/migration/model/query inspection;
- read-only query-plan/statistics access where approved;
- synthetic/local database experiments;
- migration dry-runs against disposable datasets;
- read-only historical product/engineering context.

Production DDL, destructive migration, backfill execution and retention changes require separate explicit capabilities.

## Multi-agent delivery team profiles

### Team Lead Integrator

Allow broad repository inspection, issue/docs context retrieval, shared-state coordination writes, specialist task assignment, authorized owned-workspace integration operations, PR lifecycle management, CI inspection, review response, and eligible merge through the semantic VCS capability layer. Deny unrestricted raw ref mutation and destructive history operations.

### UI Leet Engineer

Allow frontend source/test inspection and mutation only within assigned locks, read access to shared contracts and backend handoffs, local/browser test execution, and shared-state/handoff writes. Deny merge authority and unapproved backend/database/infrastructure mutation.

### Backend Leet Engineer

Allow assigned service/domain source/test mutation, API/event contract inspection, local service/test/load tooling, and shared-state/handoff writes. Deny merge authority and unapproved durable schema/infrastructure changes.

### Database Leet Engineer

Allow schema/query/migration inspection, assigned migration/model changes, local/ephemeral database validation, explain/query-plan analysis, and shared-state/handoff writes. Deny production DDL/DML authority unless separately granted and deny merge authority.

### Ops Leet Engineer

Allow assigned IaC/config/observability mutation, deployment-plan simulation, non-production validation, runtime/capacity inspection, and shared-state/handoff writes. Deny unrestricted production mutation and merge authority unless separately granted.

### QA Leet Engineer

Allow broad read access to integrated code/contracts/handoffs, test execution, ephemeral test-environment interaction, evidence capture, and QA/shared-state writes. Deny product implementation mutation by default; defects are routed through the Lead to the owning specialist.
