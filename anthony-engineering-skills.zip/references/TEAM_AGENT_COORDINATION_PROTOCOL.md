# Team Agent Coordination Protocol

## Purpose

Coordinate multiple specialist agents that each keep a narrow context window while sharing one deterministic program state. The Lead owns the outcome. Specialists own bounded implementation slices. No specialist may silently redefine cross-domain requirements.

## Shared state directory

Use the repository-local directory `.agent/team/` unless repository policy defines another location.

Required files:

- `CHARTER.md` — immutable mission, acceptance criteria, non-goals, constraints, ticket links, primary branch, environments.
- `PLAN.md` — Lead-maintained dependency graph and ordered milestones.
- `TASKS.md` — canonical task registry with owner, status, dependency, and verification state.
- `DECISIONS.md` — append-only decision log. Only Lead marks a decision final.
- `RISKS.md` — known risks, owner, trigger, mitigation, current disposition.
- `CONTRACTS.md` — shared API/schema/event/UI contracts and version state.
- `INTEGRATION.md` — integration order, merge readiness, cross-domain compatibility notes.
- `QA.md` — acceptance-test matrix, manual QA, regression state, evidence.
- `STATUS.md` — concise current program state generated from task records.
- `locks/*.lock.md` — exclusive task/path ownership leases.
- `handoffs/*.md` — completed task evidence and downstream instructions.

## Authority model

### Lead

The Lead is the sole authority for:

- interpreting ambiguous requirements after specialist input;
- final acceptance criteria;
- task decomposition and ownership;
- cross-domain contract decisions;
- priority and pace;
- conflict resolution;
- integration order;
- approval of scope changes;
- merge eligibility and merge execution;
- declaring the initiative complete.

The Lead answers questions that can be resolved from evidence. Specialists ask the Lead, not the operator, unless the Lead determines operator input is truly required.

### Specialists

A specialist may:

- claim one assigned task lock;
- make decisions wholly inside that task and domain when they do not alter shared contracts;
- propose shared-contract changes in `DECISIONS.md`;
- write implementation and tests inside declared ownership boundaries;
- publish a handoff containing evidence and unresolved concerns.

A specialist may not:

- modify another agent's owned paths without a Lead-approved ownership transfer;
- finalize a cross-domain decision;
- silently expand scope;
- merge integration work;
- resolve contract disagreement by implementation fiat.

## Lock protocol

A task lock is valid only when it contains:

- task ID;
- agent/role;
- lease timestamp;
- owned file globs, symbols, database objects, API routes, or infrastructure resources;
- explicitly allowed shared coordination files;
- dependencies that must be stable before implementation;
- expected artifacts/handoff;
- status: `claimed`, `blocked`, `handoff-ready`, or `released`.

Ownership must be as narrow as practical. Shared contracts are not implicitly owned by the agent editing an implementation.

Before writing code, run the lock validator. Overlapping ownership is a hard stop until the Lead resolves it.

## Communication rules

Use shared files as durable communication. Do not depend on chat memory between agents.

Every cross-agent statement must be one of:

- `FACT` — directly evidenced by code, test, runtime, ticket, or authoritative artifact;
- `DECISION_PROPOSAL` — suggested choice requiring Lead acceptance;
- `DECISION` — Lead-finalized choice;
- `DEPENDENCY` — work or contract required from another task;
- `RISK` — credible failure condition with trigger and mitigation;
- `HANDOFF` — finished work with validation evidence.

Reference immutable SHAs, paths, line ranges, ticket IDs, test names, schema versions, or CI runs wherever possible.

## Handoff contract

Every handoff must include:

1. task and owner;
2. acceptance criteria satisfied;
3. exact changed surfaces;
4. contracts consumed/produced;
5. tests and verification commands with results;
6. migration/deployment implications;
7. observability added or required;
8. known risks and intentionally deferred items;
9. downstream agent instructions;
10. immutable commit/workspace reference when available.

No `done` status exists without a handoff.

## Conflict resolution

When two specialists disagree:

1. each writes a short evidence-backed position;
2. each identifies the failure mode of the alternative;
3. the Lead evaluates against `CHARTER.md`, acceptance criteria, current architecture, operational risk, and reversibility;
4. the Lead records one final decision in `DECISIONS.md`;
5. all agents execute that decision without reopening it unless new material evidence appears.

## Integration readiness

A task is integration-ready only when:

- its lock is `handoff-ready`;
- all task acceptance criteria pass;
- its local test surface passes;
- contract changes are reflected in `CONTRACTS.md`;
- required migrations/deployment sequencing are documented;
- no unresolved blocking risk remains;
- the QA agent has enough information to validate the behavior.

The Lead alone determines merge order and handles merges through the authorized VCS capability layer.

## Completion

The initiative is complete only when:

- all acceptance criteria are verified;
- all required tasks have accepted handoffs;
- integration is complete;
- the full required CI pipeline is green;
- QA signs off or documents the exact blocking failure;
- operational rollout and rollback conditions are understood;
- no task locks remain claimed.
