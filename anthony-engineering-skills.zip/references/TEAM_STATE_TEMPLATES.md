# Team Agent Shared-State Templates

## `.agent/team/CHARTER.md`

```md
# Charter

## Mission

## Ticket / source artifacts

## Acceptance criteria
- AC-1:
  - Evidence:
  - Validation:

## Non-goals

## Constraints

## Primary contracts

## Completion gate
```

## `.agent/team/TASKS.md`

```md
# Tasks

| ID | Owner | Domain | Status | Depends on | Lock | Handoff | Verification |
|---|---|---|---|---|---|---|---|
```

Statuses: `queued`, `ready`, `claimed`, `blocked`, `handoff-ready`, `integrated`, `verified`, `closed`.

## `.agent/team/DECISIONS.md`

```md
# Decisions

## DEC-001 — <title>
- Status: proposed | final | superseded
- Proposed by:
- Finalized by: Lead
- Context:
- Evidence:
- Options considered:
- Decision:
- Failure mode avoided:
- Consequences:
- Reopen only if:
```

## `.agent/team/CONTRACTS.md`

```md
# Shared Contracts

## CONTRACT-001 — <name>
- Owner:
- Consumers:
- Status: proposed | stable | migrating | deprecated
- Shape/version:
- Invariants:
- Compatibility promise:
- Failure semantics:
- Evidence:
```

## `.agent/team/RISKS.md`

```md
# Risks

| ID | Risk | Trigger | Impact | Owner | Mitigation | Status |
|---|---|---|---|---|---|---|
```

## `.agent/team/INTEGRATION.md`

```md
# Integration

## Order
1.

## Gates

## Cross-domain checks

## Merge/conflict decisions

## Deployment/migration order
```

## `.agent/team/QA.md`

```md
# QA Matrix

| Acceptance criterion | Automated evidence | Manual scenario | Failure modes | Status |
|---|---|---|---|---|
```

## `.agent/team/handoffs/<TASK>.md`

```md
# Handoff: <TASK>

- Owner:
- Status: handoff-ready
- Commit/workspace evidence:

## Acceptance criteria satisfied

## Changed surfaces

## Contracts consumed/produced

## Verification evidence

## Migration/deployment implications

## Observability

## Known risks / deferred work

## Downstream instructions
```
