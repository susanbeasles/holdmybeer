#!/usr/bin/env python3
"""Heuristic OpenAPI contract audit. Supports JSON and YAML when PyYAML exists."""
import argparse, json, sys

def load(p):
    text=open(p,encoding='utf-8').read()
    try:return json.loads(text)
    except Exception:
        try:
            import yaml; return yaml.safe_load(text)
        except Exception as e: raise SystemExit(f"Unable to parse contract as JSON/YAML: {e}")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('spec'); a=ap.parse_args(); d=load(a.spec); findings=[]; ops=0
    for route,item in (d.get('paths') or {}).items():
        for method,op in (item or {}).items():
            if method.lower() not in {'get','post','put','patch','delete'} or not isinstance(op,dict): continue
            ops+=1; responses=op.get('responses') or {}; params=(item.get('parameters') or [])+(op.get('parameters') or [])
            codes={str(x) for x in responses}
            if not any(c.startswith('4') for c in codes): findings.append({'severity':'medium','route':route,'method':method,'issue':'no documented 4xx response'})
            if not any(c.startswith('5') or c=='default' for c in codes): findings.append({'severity':'low','route':route,'method':method,'issue':'no documented server/default failure response'})
            if method.lower()=='get' and ('{' not in route) and not any((p.get('name') or '').lower() in {'limit','cursor','page','pagesize','page_size'} for p in params if isinstance(p,dict)):
                findings.append({'severity':'medium','route':route,'method':method,'issue':'collection-like GET has no obvious pagination parameter'})
            if method.lower()=='post' and not any((p.get('name') or '').lower() in {'idempotency-key','idempotency_key'} for p in params if isinstance(p,dict)):
                findings.append({'severity':'info','route':route,'method':method,'issue':'POST has no documented idempotency key; verify operation semantics'})
    print(json.dumps({'operations':ops,'findings':findings},indent=2))
if __name__=='__main__':main()
