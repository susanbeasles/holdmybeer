#!/usr/bin/env node
import { execFileSync } from 'node:child_process';
import process from 'node:process';

const args = process.argv.slice(2);
const opt = (name, fallback = null) => {
  const i = args.indexOf(name);
  return i >= 0 && i + 1 < args.length ? args[i + 1] : fallback;
};
const path = opt('--path');
const rev = opt('--rev', 'HEAD');
const max = Number(opt('--max', '25'));
if (!path) {
  console.error('usage: triage-dossier.mjs --path <path> [--rev <rev>] [--max 25]');
  process.exit(2);
}
const git = (...a) => execFileSync('git', a, { encoding: 'utf8', stdio: ['ignore','pipe','pipe'] }).trim();
const safe = (fn) => { try { return fn(); } catch (e) { return { error: e.stderr?.toString().trim() || e.message }; } };
const oid = safe(() => git('rev-parse', '--verify', `${rev}^{commit}`));
const status = safe(() => git('status', '--porcelain=v1', '--branch'));
const log = safe(() => git('log', `-${max}`, '--follow', '--date=iso-strict', '--format=%H%x09%P%x09%an%x09%ae%x09%aI%x09%cI%x09%s', '--', path)
  .split('\n').filter(Boolean).map(line => {
    const [commit, parents, author, email, authored, committed, subject] = line.split('\t');
    return { commit, parents: parents ? parents.split(' ') : [], author, email, authored, committed, subject };
  }));
const blame = safe(() => git('blame', '--line-porcelain', rev, '--', path));
const blameSummary = typeof blame === 'string' ? (() => {
  const counts = new Map();
  for (const line of blame.split('\n')) {
    const m = line.match(/^([0-9a-f]{40}) \d+ \d+(?: \d+)?$/);
    if (m) counts.set(m[1], (counts.get(m[1]) || 0) + 1);
  }
  return [...counts.entries()].sort((a,b) => b[1]-a[1]).slice(0,10).map(([commit, lines]) => ({ commit, lines }));
})() : blame;
const out = {
  schema: 'triage-dossier/v1',
  generatedAt: new Date().toISOString(),
  revision: rev,
  resolvedRevision: oid,
  path,
  bounds: { maxCommits: max },
  workspaceStatus: status,
  recentPathHistory: log,
  topBlameOrigins: blameSummary
};
console.log(JSON.stringify(out, null, 2));
