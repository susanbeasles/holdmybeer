#!/usr/bin/env python3
import argparse, subprocess, json, datetime

def run(*a):
    p=subprocess.run(['git',*a],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    return p.returncode,p.stdout.rstrip('\n'),p.stderr.rstrip('\n')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--range', dest='range_', default='--all')
    ap.add_argument('--max', type=int, default=200)
    ns=ap.parse_args()
    range_args=['--all'] if ns.range_=='--all' else [ns.range_]
    fmt='%H%x1f%P%x1f%T%x1f%an%x1f%ae%x1f%aI%x1f%cn%x1f%ce%x1f%cI%x1f%G?%x1f%GF%x1f%s'
    rc,out,err=run('log',*range_args,f'-{ns.max}',f'--format={fmt}','--date=iso-strict','--topo-order')
    if rc: raise SystemExit(err)
    commits=[]
    for line in out.splitlines():
        p=line.split('\x1f')
        if len(p)<12: continue
        commits.append({
          'oid':p[0],'parents':p[1].split() if p[1] else [],'tree':p[2],
          'author':{'name':p[3],'email':p[4],'time':p[5]},
          'committer':{'name':p[6],'email':p[7],'time':p[8]},
          'signature':{'status':p[9],'fingerprint':p[10] or None},'subject':p[11]
        })
    anomalies=[]
    by={c['oid']:c for c in commits}
    for c in commits:
        if c['author']['email'] != c['committer']['email']:
            anomalies.append({'oid':c['oid'],'kind':'author_committer_identity_divergence'})
        if c['signature']['status'] not in ('G','U','X','Y','R'):
            anomalies.append({'oid':c['oid'],'kind':'signature_not_verified','status':c['signature']['status']})
        for parent in c['parents']:
            if parent in by and c['committer']['time'] < by[parent]['committer']['time']:
                anomalies.append({'oid':c['oid'],'parent':parent,'kind':'committer_time_precedes_parent'})
    print(json.dumps({'schema':'history-reconstruction/v1','generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commits':commits,'anomalies':anomalies},indent=2))
if __name__=='__main__': main()
