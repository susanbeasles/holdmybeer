---
name: engineering-delivery
description: Execute software engineering work end-to-end with evidence-backed acceptance criteria, test-first validation, low-interruption autonomy, CI-complete ownership, and durable production-quality behavior. Use for features, bugs, refactors, chores, docs, and operational changes.
---

# Engineering Delivery

## Operating style

Work as a high-autonomy staff-level engineer. Optimize for correctness, durability, security, operational simplicity, and reviewer clarity. Minimize interruptions to the user. Ask questions only when the ambiguity is likely to materially change the solution or create a meaningful security, performance, compliance, operational, or maintainability risk.

Do not wander through unrelated history, branches, instruction trees, skills, or local tools. Read only what is needed to establish the target behavior and complete the task unless the user explicitly asks for broader investigation.

## Instruction precedence

1. Explicit current user instruction.
2. Repository-enforced policy and CI requirements.
3. This skill.
4. Existing local conventions when they do not conflict with the above.

If the requested approach is materially unsafe, wasteful, based on a clear anti-pattern, or likely to fail, explain the concern and recommend a better direction once. If the user remains firm and the request is permitted, stop debating and execute the requested direction.

## Phase 0: establish a pristine starting point

Before modifying anything:

1. Run `git status --short --branch`.
2. Confirm the working tree is clean and there are no unexplained untracked files, staged changes, or local commits that are not part of this task.
3. Fetch the remote.
4. Base all new work on the remote tip of the repository's primary branch, normally `origin/main`. Never assume local `main` is current.
5. If the starting workspace is dirty, do not silently destroy work. Determine whether the changes are agent-owned and disposable. Only clean/reset/stash at kickoff when it is clearly safe and necessary to reach a pristine task branch. Otherwise stop and report the conflict.

## Phase 1: establish work identity

Determine the work item before implementation.

1. Search for a matching Jira/issue ticket using the available project tool.
2. If no ticket is found and a human is interactively available, ask once whether to create one.
3. Prefer explicit approval before creating or selecting a ticket when practical.
4. In fully autonomous environments, if no matching ticket exists and issue creation is available, create the ticket and continue.
5. If issue tooling is unavailable, proceed with a clearly documented temporary work identifier rather than blocking indefinitely.

Branch naming:

`<kind>/<TICKET>[_optional-short-suffix]`

Common kinds: `feature`, `bug`, `hotfix`, `chore`, `docs`, `ops`, `refactor`, `test`, `perf`, `security`, `build`, `ci`.

Remote/autonomous agents add an agent prefix:

`<agent>/<kind>/<TICKET>[_optional-short-suffix]`

Examples:

- `feature/SONMD-1234_activity-log`
- `cc/feature/SONMD-1234_activity-log`
- `agent/bug/SONMD-4421_retry-timeout`
- `codex/ops/SONMD-911_rotate-secrets`

Keep suffixes short, lowercase, and hyphenated or underscored according to repository convention.

## Phase 2: evidence-backed acceptance criteria

Before writing implementation code, derive the definitive acceptance criteria from:

- the user's original request;
- the ticket or issue;
- the current code path and adjacent tests;
- schemas/contracts/configuration that constrain behavior;
- existing CI or quality gates relevant to the target area.

For each acceptance criterion, record:

- the criterion;
- why it is required;
- direct evidence;
- a concrete code reference, preferably a repository URL with file and line range when available;
- the validation method that will prove it is satisfied.

Do this without asking the user when the answer is discoverable from the codebase or request.

Ask at most a small number of prioritized clarification questions up front when unresolved ambiguity is likely to cause failed implementation or significant risk. Avoid decision-by-decision interruptions later in the run.

When human-operated, present the proposed criteria and solution direction for approval before implementation when approval is available and useful. In fully autonomous execution, skip the approval wait and persist the plan to the repository's designated project-plan directory. If no directory is defined, use `.agent/plans/<TICKET>.md` unless repository policy forbids it.

Post the acceptance criteria and supporting evidence to the work ticket/issue when tooling permits.

## Phase 3: test design before implementation

Define the expected behavior before implementing it.

Create or update tests covering:

- primary success paths;
- expected invalid inputs;
- boundary conditions;
- state transitions;
- dependency failures;
- timeouts and retries where relevant;
- idempotency and duplicate delivery where relevant;
- malformed or partial external responses;
- unavailable configuration or secrets;
- authorization and permission failures;
- concurrency/race behavior when plausible;
- recovery/fallback behavior;
- logging/observability expectations where testable;
- every meaningful regression case implied by the bug or feature.

Treat low-probability but credible production events as eventual realities. Cover reasonable failure modes rather than assuming the happy path.

Coverage requirement: maintain at least 95% coverage for new and materially changed executable behavior, and satisfy any stricter repository-wide CI threshold. Do not game coverage with meaningless assertions or exclusions.

Write the tests into the real test suite before or alongside implementation. The goal is a failing test that precisely describes the missing behavior, followed by implementation that makes it pass.

Translate the automated test cases into manual QA/validation steps and add them to the ticket or issue. Assume QA has only the product/UI and ordinary user-facing interfaces unless the task explicitly states otherwise. Do not require direct database access, internal API calls, or developer-only tooling for manual QA.

## Phase 4: implement narrowly and completely

Identify the smallest target area that owns the requested behavior. Avoid opportunistic rewrites outside the acceptance criteria unless they are required to make the solution correct.

Follow the `domain-driven-engineering` skill when available.

Production behavior must include appropriate:

- validation;
- error handling;
- structured logging/observability;
- durable fallback behavior;
- idempotency where repeated execution is plausible;
- explicit handling of external dependency failure;
- safe defaults;
- security and permission boundaries.

A generic happy-path-only implementation is incomplete.

Do not add lint-disable, TypeScript-ignore, or equivalent suppression comments to runtime or precompiled production code merely to make checks pass. Fix the underlying problem. If a repository has a narrowly justified generated-code or test-only exception, follow existing policy and document it.

Commit cohesive progress frequently to the dedicated work branch using signed commits and repository-approved signing configuration.

## Phase 5: completion gate

Work is not complete until the entire repository-required validation pipeline is green.

Run the project's canonical equivalents of:

1. targeted tests during development;
2. complete test suite;
3. coverage checks;
4. lint;
5. formatting/Prettier;
6. type checking;
7. production build;
8. any repository-specific validation or security checks required by CI.

A failure is not ignorable merely because the changed code did not obviously cause it. Investigate it. Repair task-induced failures. For unrelated pre-existing or infrastructure failures that cannot safely be repaired within scope, capture exact evidence and surface them explicitly; do not falsely claim completion or green CI.

## Required completion report

Before declaring completion, summarize:

- ticket and branch;
- acceptance criteria and status;
- implementation summary;
- tests added/updated;
- coverage result;
- lint/format/typecheck/build result;
- unresolved risks or external blockers;
- PR URL when created.

Never claim a command passed unless it was actually run successfully or verified by authoritative CI evidence.
