---
name: git-pr-governance
description: Govern engineering work from ticket and branch creation through signed conventional commits, reviewer-oriented pull requests, CI/review resolution, and safe merge completion.
---

# Git and Pull Request Governance

## Ticket first

Associate meaningful engineering work with a Jira/issue ticket when issue tooling exists.

Search for a matching ticket before creating a new one. Ask once for approval when a human is available and the choice is ambiguous. In autonomous mode, create a ticket when no appropriate existing ticket can be found and permissions allow it.

Use uppercase ticket identifiers in durable artifacts, for example `SONMD-1234`.

## Branch naming

Branch from the fetched remote primary branch tip, normally `origin/main`, not a stale local `main`.

Human-operated branch:

`<kind>/<TICKET>[_short-suffix]`

Autonomous agent branch:

`<agent>/<kind>/<TICKET>[_short-suffix]`

Recommended kinds:

- `feature`
- `bug`
- `hotfix`
- `chore`
- `docs`
- `ops`
- `refactor`
- `test`
- `perf`
- `security`
- `build`
- `ci`

Examples:

- `feature/SONMD-1234_activity-log`
- `codex/feature/SONMD-1234_activity-log`
- `cc/bug/SONMD-998_retry-race`

## Commit protocol

Use signed commits with an approved signing identity/key.

Use Conventional Commits plus the ticket identifier:

`<type>(<scope>): <TICKET> - <short description>`

Examples:

- `feat(activity): SONMD-1234 - integrate activity log API`
- `fix(survey): SONMD-2041 - prevent duplicate response submission`
- `test(claim): SONMD-3344 - cover retry idempotency`
- `chore(ci): SONMD-5501 - enforce production typecheck`

Valid types should follow repository commitlint configuration. Common values are `feat`, `fix`, `refactor`, `test`, `docs`, `chore`, `build`, `ci`, `perf`, and `revert` only when repository policy explicitly allows reverts.

Commit cohesive increments often enough that progress is recoverable and reviewable.

## VCS capability boundary

Raw Git and direct repository mutation APIs are forbidden to the agent. The agent must operate exclusively through the approved semantic VCS abstraction defined in `../references/VCS_TOOL_CONTRACT.md`.

This prohibition includes Git CLI write commands, `gh`/`glab` mutation commands, direct GitHub/GitLab/Bitbucket mutation APIs, unrestricted MCP repository-write tools, and arbitrary REST/GraphQL repository mutations. The transport behind an approved VCS tool may use those mechanisms internally; the agent may not select or invoke them directly.

The authorized abstraction exposes intent-level operations such as:

- `repo.prepareWorkspace()`
- `repo.createWorkBranch(ticket, kind, suffix?, agent?)`
- `repo.stage(paths?)`
- `repo.commitChange(type, scope, ticket, description)`
- `repo.syncPrimary()`
- `repo.publishWorkBranch()`
- `repo.openPullRequest(...)`
- `repo.updatePullRequest(...)`
- `repo.respondToReview(...)`
- `repo.mergeEligiblePullRequest(...)`

Repository inspection is intentionally read-rich. Use the forensic/history operations in `../references/VCS_TOOL_CONTRACT.md` when the task requires blame, ancestry reconstruction, raw commit metadata, signature verification, reflog/ref movement analysis, patch equivalence, provider event correlation, or conflict topology. Bound broad traversals with explicit queries or pagination, but do not artificially suppress history analysis when history is the task.

Conflict analysis should prefer isolated ephemeral operations such as `repo.simulateMerge()`, `repo.conflictDetails()`, `repo.rangeDiff()`, `repo.patchId()`, and disposable analysis workspaces. These capabilities may calculate or materialize candidate trees without moving durable refs.

If the necessary authorized operation is unavailable, stop that mutation step and report the missing capability. Never fall back to a raw command, shell script, generic provider API, or lower-level write tool.

## Workspace and branch preparation

Before work begins, call the authorized workspace-preparation operation and require a pristine result: no unintended staged files, unstaged modifications, dangling untracked files, or ambiguous branch state. Preserve pre-existing human work by default. Any startup-only cleanup behavior must be implemented inside the approved wrapper and must return evidence of what it changed.

Create the work branch using the authorized branch operation. The wrapper must cut it from the current remote primary-branch tip rather than a stale local branch and must enforce the naming rules above.

## Commit and synchronization policy

Commits must be created only through the authorized signed-commit operation using structured Conventional Commit fields. Commit cohesive increments often enough that progress is recoverable and reviewable.

Immediately before PR creation, use the authorized synchronization operation. The wrapper—not the agent—decides whether the repository-approved implementation is merge, rebase, fast-forward, or another safe strategy. It must never rewrite protected/shared branches, must never use blanket conflict resolution, and may use lease-protected publication only when required by an approved synchronization of the agent-owned branch.

After synchronization, rerun the complete validation gate and publish using the authorized push operation. The agent is never authorized to request arbitrary force behavior.

## Pull request format

### Title

`<TICKET> - <short description>`

Example:

`SONMD-1234 - Integrate the activity log API`

### Body

Include ticket URLs and every useful linkable artifact, followed by these sections:

#### What

State substantively what was added, removed, or changed. Use a compact paragraph or bullets when that is clearer.

#### How

Explain the implementation approach, important techniques, alternatives considered, and relevant tradeoffs.

#### Why

Explain why this approach was chosen in the actual system context. State meaningful upsides, downsides, risks, and why the selected tradeoff beats the alternatives.

#### Reviewer context

Give reviewers the context needed to understand the change quickly: affected domains, non-obvious constraints, migration/deployment concerns, compatibility assumptions, intentionally unchanged behavior, test/QA guidance, observability, rollout/rollback considerations, and areas that deserve extra scrutiny.

Write the PR for the reviewer. Optimize for fast understanding and high-quality review, not for project-management theater.

## Review workflow

When the platform supports it:

1. Mark the PR ready for review after the full local validation gate passes.
2. Request the configured engineering reviewer group. Use repository/team configuration as the source of truth rather than hard-coding stale handles.
3. If the organization uses agent reviewers, tag the configured reviewer agents such as `@codex` and `@claude` in a PR comment.
4. Respond to every substantive review comment. Either change the code, explain with evidence why no change is appropriate, or resolve the thread according to team policy.
5. Rerun relevant tests after every code change and rerun the full required gate before merge.
6. Do not consider the task complete while required CI checks are red or pending.

If reviewer handles are not centrally configured, the historical seed list supplied by the user is:

- `avespoli-sonarmd`
- `cforrester-sonarmd`
- `vsiqueira-sonarmd`
- `tru nguyen` (resolve to the exact GitHub handle before use)
- `calonina`
- `ehelena`

Do not guess an uncertain handle; resolve it from repository/org metadata.

## Agent review polling

After tagging automated peer reviewers, wait only when the execution environment explicitly supports scheduled/polling work. Otherwise, perform one immediate follow-up check near the end of the run.

If a tagged agent reacts with an eyes/inspection indicator, treat that as review-in-progress rather than completion. If no automated reviewer response is present and the environment cannot remain active, report that state and end the run cleanly.

Do not claim to have slept or polled asynchronously when the execution environment cannot do so.

## Merge eligibility

A PR is eligible to merge only when:

- acceptance criteria are satisfied;
- all required local checks pass;
- all required CI checks are green;
- required reviews/approvals are satisfied;
- substantive review threads are resolved;
- branch protection and repository policy allow the merge.

Use the repository-approved automated merge mechanism when available. Never bypass branch protection or required review policy.

After merge, verify the PR reports the expected merged state and that the target branch is the intended primary branch.
