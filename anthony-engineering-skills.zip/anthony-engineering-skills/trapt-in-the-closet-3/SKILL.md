---
name: trapt-in-the-closet-3
description: Choose the least-damaging forward path when architecture, migrations, contracts, or operational constraints have already created a corner with no clean exit. Use for damage-control decisions where every option incurs real cost and the objective is to minimize irreversible harm while restoring future optionality.
---

# Trapt in the Closet 3 — Pissed on the Wrong Agent

## Mission

Use this skill when there is **no clean solution left**.

The system may already contain incompatible contracts, partially completed migrations, duplicated sources of truth, bad ownership boundaries, accumulated coupling, production dependencies, customer commitments, or operational constraints that make every available exit painful.

Do not pretend otherwise. Do not optimize for elegance. Do not defend sunk work.

The objective is:

> **Choose the forward path that minimizes irreversible harm, contains unavoidable damage, restores a coherent architectural boundary, and leaves the system in the best position to make the next decision cleanly.**

This is architectural extraction under damage.

## Trigger conditions

Use when one or more are true:

- every viable path breaks or deprecates something meaningful;
- an earlier architectural decision has made clean migration impossible;
- two sources of truth already exist and cannot be atomically reconciled;
- a public API, persisted schema, event contract, or operational dependency prevents a clean redesign;
- a partial migration has crossed the point where simple rollback is no longer safe;
- the system contains cyclic dependencies or ownership boundaries that make local repair impossible;
- customer, compliance, traffic, or availability constraints eliminate the theoretically clean solution;
- Optionality Architect cannot produce a valid low-cost holding pattern;
- delay compounds damage faster than it produces useful information.

Do not use this skill for ordinary tradeoffs. There must be a real corner.

## Prime directives

1. **Ignore sunk cost.** Prior implementation effort has zero positive weight unless abandoning it creates new harm.
2. **Prevent irreversible damage first.** Data loss, security exposure, compliance failure, permanent contract corruption, and uncontrolled blast radius dominate elegance and delivery speed.
3. **Externalize as little pain as possible.** Prefer costs paid internally by the implementation over costs imposed on customers, downstream teams, operators, or future migrations.
4. **Pay debt once.** If damage is unavoidable, concentrate it in one bounded migration or compatibility layer instead of creating indefinite distributed tax.
5. **Restore one truth.** End states with ambiguous authority, dual ownership, or permanently competing sources of truth are strongly disfavored.
6. **Move forward.** Do not require history rewriting, destructive rollback, or pretending the previous state never happened.
7. **Leave a clean seam.** The chosen extraction should create a boundary from which future work can proceed normally.
8. **Do not optimize for embarrassment.** The least politically awkward option is irrelevant. Optimize for system outcomes.

## Evidence requirements

Before recommending an exit, establish an evidence packet containing:

- current executable behavior;
- current production/public contracts;
- persisted data shape and authoritative source(s);
- irreversible operations already performed;
- active consumers and dependencies;
- migration state and population percentages when measurable;
- traffic, latency, availability, and operational constraints;
- security/compliance boundaries;
- known failure modes;
- exact point at which the system became cornered, when identifiable;
- decisions that remain reversible vs decisions already spent.

Classify claims using `references/AGENT_EVIDENCE_STANDARD.md`.

Historical Jira/Confluence intent is useful context but does not override executable reality.

## Step 1 — State the corner without euphemism

Write:

**Corner:** `<one paragraph describing why no zero-cost path exists>`

Then identify the mutually incompatible constraints.

Example shape:

- Contract A must remain compatible for existing consumers.
- Data written after migration point B cannot safely return to schema A.
- Service C is already authoritative for new writes.
- Legacy readers still require representation D.

If the constraints are not actually incompatible, stop using this skill and solve the normal problem.

## Step 2 — Draw the damage boundary

Identify what can still be protected.

Partition the system into:

- **must preserve** — data integrity, security, compliance, externally relied-upon semantics;
- **may degrade temporarily** — latency, internal convenience, duplicate compute, operational toil;
- **may intentionally break with migration** — internal APIs, obsolete abstractions, temporary compatibility code;
- **must eliminate** — split authority, silent corruption, indefinite dual write, unsafe fallback behavior.

Do not allow all concerns to become equally important.

## Step 3 — Generate three extraction paths

Produce exactly three credible forward exits. They must lead to materially different end states or migration strategies.

Do not include a fake option that obviously exists only to make the preferred choice look better.

Each path must specify:

- final authority/source of truth;
- final public and internal contract shape;
- migration sequence;
- compatibility mechanism;
- blast radius;
- irreversible actions;
- temporary artifacts;
- data reconciliation strategy;
- rollback boundary, if any remains;
- operational burden during extraction;
- expected time spent in dangerous intermediate states;
- cleanup/removal conditions;
- resulting architectural position after extraction.

## Step 4 — Score with lexicographic damage control

Do **not** use a naive weighted average where enough convenience can compensate for catastrophic risk.

Evaluate in this order:

### Tier 0 — Disqualifiers

Reject a path if it creates an avoidable material risk of:

- unrecoverable data loss or corruption;
- security boundary bypass;
- compliance violation;
- uncontrolled writes to two authorities;
- permanent ambiguity about source of truth;
- unbounded customer-facing incompatibility;
- migration without an observable completion condition.

Only retain such a path if every path contains the same unavoidable class of harm; if so, explicitly state that fact.

### Tier 1 — Irreversible blast radius

Minimize:

- irreversible data transformations;
- public contract breakage;
- number of affected consumers;
- permanent operational dependencies;
- one-way infrastructure commitments;
- duration and reach of inconsistent state.

### Tier 2 — Future recovery position

Maximize:

- single ownership;
- clean domain boundary;
- stable contract seam;
- ability to delete compatibility code;
- ability to choose future architecture without first repairing this extraction;
- observability of correctness.

### Tier 3 — Contained temporary pain

Then minimize:

- duplicate compute/storage;
- migration toil;
- engineering effort;
- temporary latency;
- deployment complexity;
- support burden.

### Tier 4 — Delivery speed

Only after the above, prefer the faster path.

## Step 5 — Compute the "piss radius"

For each surviving path, explicitly identify **who pays**.

Report impact on:

- end users;
- downstream consumers;
- data/analytics;
- operators/SRE;
- feature engineers;
- security/compliance;
- future maintainers;
- infrastructure cost.

Prefer a path where unavoidable pain is bounded to the team performing the extraction rather than exported to every future caller.

A locally expensive migration can be superior to a cheap implementation that makes every consumer permanently compensate.

## Step 6 — Identify the sacrificial layer

When something must absorb complexity, choose it deliberately.

Prefer temporary complexity in this order:

1. bounded migration tooling;
2. explicitly temporary compatibility adapter;
3. isolated translation boundary;
4. temporary read fallback with measured removal condition;
5. temporary duplicate computation for verification.

Strongly avoid placing unavoidable mess into:

- core domain entities;
- public contracts;
- canonical persisted representation;
- authorization rules;
- global utility abstractions;
- every caller.

The sacrificial layer must have an owner and deletion predicate.

## Step 7 — Find the point of no return

For the selected path, state:

- last reversible step;
- first irreversible step;
- preconditions required before crossing it;
- validation immediately before crossing;
- evidence required immediately after crossing;
- abort behavior if validation fails.

Never hide the point of no return inside a multi-step deploy.

## Step 8 — Produce a forward extraction sequence

The selected plan must be executable as small checkpoints.

Prefer:

1. instrument reality;
2. establish destination boundary;
3. introduce compatibility at one seam;
4. migrate/backfill/reconcile;
5. shadow or compare behavior;
6. move authority exactly once;
7. verify all consumers and invariants;
8. remove obsolete path;
9. delete temporary compatibility;
10. document the new invariant.

Not every case requires all ten, but authority transitions must be explicit.

## Step 9 — Define done

"Stable for now" is not done.

The extraction is complete only when:

- one source of truth exists;
- temporary dual behavior is removed or has an explicit accepted long-term role;
- compatibility artifacts scheduled for deletion are deleted;
- all relevant invariants are verified;
- observability can detect regression;
- public/internal ownership is clear;
- the next architectural decision can be made without first untangling this incident;
- CI and production validation are green.

## Output contract

Return this structure.

### Situation

**Corner:** why a clean exit no longer exists.

**Evidence:** immutable/current evidence proving the constraint set.

**Damage already spent:** irreversible costs that must be treated as sunk.

**Still protectable:** boundaries and invariants that remain under our control.

### Exit A — `<name>`

- End state
- Migration sequence
- Source of truth
- Piss radius
- Irreversible damage
- Temporary pain
- Cleanup burden
- Future position
- Confidence

### Exit B — `<name>`

Same fields.

### Exit C — `<name>`

Same fields.

### Selected extraction — `<name>`

**Why this loses least:** direct comparison against the other two.

**Sacrificial layer:** where temporary complexity is intentionally concentrated.

**Point of no return:** exact transition and prerequisites.

**Execution checkpoints:** ordered, independently verifiable steps.

**Abort conditions:** conditions that halt before further irreversible movement.

**Validation:** evidence proving the extraction is working.

**Cleanup:** exact temporary artifacts and deletion predicates.

**New invariant:** one sentence describing the coherent state that exists afterward.

**Residual debt:** unavoidable damage that remains after extraction; do not hide it.

**Confidence:** 0.0-1.0.

## Deterministic tie-breakers

When two paths remain close, choose in this order:

1. fewer irreversible effects;
2. smaller external/customer blast radius;
3. shorter duration with multiple authorities;
4. cleaner final ownership boundary;
5. fewer permanent compatibility requirements;
6. easier correctness verification;
7. lower recurring operational cost;
8. lower implementation cost;
9. faster delivery.

## Anti-patterns

Never recommend:

- indefinite dual-write as an "architecture";
- permanent translation logic scattered across callers;
- a generic abstraction whose only purpose is hiding two incompatible models;
- rewriting history to make the migration look clean;
- destructive rollback after new authoritative data has been accepted without proof it is lossless;
- maintaining two canonical representations indefinitely because choosing is uncomfortable;
- suppressing errors or reconciliation mismatches to make dashboards green;
- another deferral option when uncertainty is no longer the limiting factor;
- spending significant effort preserving an implementation solely because significant effort was already spent on it.

## Relationship to other skills

- Use **Context Cartographer** first when the corner itself is unclear.
- Use **Optionality Architect** instead when a low-cost reversible holding pattern still exists.
- Use **Data Model Specialist** when the primary damage concerns persisted authority, identity, invariants, or migration semantics.
- Use **Backend UX Specialist** when extraction changes caller contracts or failure behavior.
- Use **High-Pressure DX Architect** when the extraction establishes a pattern many teams will inherit.
- Hand the chosen extraction to **Engineering Delivery** for implementation.
