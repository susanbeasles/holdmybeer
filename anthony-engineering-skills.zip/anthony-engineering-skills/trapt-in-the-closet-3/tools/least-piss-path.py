#!/usr/bin/env python3
"""Rank damaged-system extraction paths using lexicographic harm minimization.

Input JSON:
{
  "paths": [
    {
      "name": "...",
      "disqualifiers": [],
      "irreversible": {"data":0,"contracts":0,"consumers":0,"inconsistent_state":0},
      "recovery": {"single_authority":5,"clean_boundary":5,"deletable_compat":5,"observable":5},
      "temporary": {"ops":0,"compute":0,"migration":0,"support":0},
      "delivery": {"effort":0,"time":0}
    }
  ]
}

Scores are ordinal integers. Lower harm is better; recovery dimensions are higher-is-better.
Disqualified paths sort after non-disqualified paths. The program intentionally does not
collapse tiers into one weighted average.
"""
import argparse
import json
import sys


def total(mapping):
    return sum(float(v) for v in (mapping or {}).values())


def key(path):
    disq = len(path.get("disqualifiers") or [])
    irreversible = total(path.get("irreversible"))
    recovery_penalty = -total(path.get("recovery"))
    temporary = total(path.get("temporary"))
    delivery = total(path.get("delivery"))
    return (1 if disq else 0, disq, irreversible, recovery_penalty, temporary, delivery)


def explain(path):
    return {
        "name": path.get("name", "unnamed"),
        "disqualified": bool(path.get("disqualifiers")),
        "disqualifiers": path.get("disqualifiers") or [],
        "tier_scores": {
            "irreversible_harm": total(path.get("irreversible")),
            "future_recovery": total(path.get("recovery")),
            "temporary_pain": total(path.get("temporary")),
            "delivery_cost": total(path.get("delivery")),
        },
        "lexicographic_key": list(key(path)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", nargs="?", default="-", help="JSON file or - for stdin")
    args = parser.parse_args()
    raw = sys.stdin.read() if args.input == "-" else open(args.input, encoding="utf-8").read()
    doc = json.loads(raw)
    paths = doc.get("paths") or []
    if len(paths) < 2:
        raise SystemExit("need at least two extraction paths")
    ranked = sorted(paths, key=key)
    out = {
        "method": "lexicographic-damage-control",
        "selected": ranked[0].get("name", "unnamed"),
        "ranking": [explain(p) for p in ranked],
        "warning": "Ordinal scoring is decision support. Validate all Tier 0 risks from primary evidence before acting."
    }
    json.dump(out, sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
