#!/usr/bin/env python3
"""Heuristic inventory of common SQL/ORM model declarations and migration files."""
from pathlib import Path
import argparse,json,re
SKIP={'.git','node_modules','dist','build','.next','vendor'}
patterns=[
 ('sql_table',re.compile(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?["`]?([\w.]+)',re.I)),
 ('prisma_model',re.compile(r'^\s*model\s+(\w+)\s*\{',re.M)),
 ('typeorm_entity',re.compile(r'@Entity\s*\([^)]*\)\s*(?:export\s+)?class\s+(\w+)',re.S)),
 ('sequelize_model',re.compile(r'\b(?:sequelize\.define|Model\.init)\s*\(\s*[\'\"]([^\'\"]+)',re.I)),
 ('django_model',re.compile(r'^class\s+(\w+)\s*\(\s*models\.Model\s*\)',re.M)),
]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('root',nargs='?',default='.');a=ap.parse_args();root=Path(a.root).resolve();items=[];migrations=[]
 for p in root.rglob('*'):
  if not p.is_file() or any(x in SKIP for x in p.parts):continue
  rel=str(p.relative_to(root)); low=rel.lower()
  if 'migration' in low or '/migrations/' in '/'+low: migrations.append(rel)
  if p.suffix.lower() not in {'.sql','.prisma','.ts','.js','.py'}:continue
  try:s=p.read_text(errors='ignore')
  except:continue
  for kind,pat in patterns:
   for m in pat.finditer(s):items.append({'kind':kind,'name':m.group(1),'file':rel})
 print(json.dumps({'models':items,'migration_files':sorted(migrations)[:500]},indent=2))
if __name__=='__main__':main()
