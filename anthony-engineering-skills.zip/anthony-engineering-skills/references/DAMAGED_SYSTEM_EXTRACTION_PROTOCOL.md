# Damaged-System Extraction Protocol

Use when a system is already past the point where a clean, zero-cost architectural choice exists.

## Objective

Minimize irreversible harm first, external blast radius second, future architectural impairment third, temporary internal pain fourth, and delivery cost last.

This ordering is intentional. Do not use a weighted average that permits many minor benefits to offset one catastrophic risk.

## Required comparison dimensions

For every exit path record:

- Tier 0 disqualifiers: data loss/corruption, security/compliance violation, uncontrolled multi-authority writes, permanent source-of-truth ambiguity, unbounded contract breakage.
- Tier 1 irreversible harm: persisted transformations, public contract changes, consumer count, one-way infrastructure commitments, duration of inconsistent state.
- Tier 2 recovery position: single authority, clean ownership boundary, stable seam, deletable compatibility code, observability, ability to evolve afterward.
- Tier 3 temporary pain: compute/storage duplication, migration toil, operational burden, latency, support burden, test-matrix expansion.
- Tier 4 delivery: engineering effort and elapsed rollout complexity.

## Required extraction properties

A selected path must:

1. identify one final source of truth;
2. identify a single intentional sacrificial layer for temporary complexity;
3. name the last reversible step and first irreversible step;
4. expose abort conditions before the point of no return;
5. migrate authority explicitly rather than implicitly;
6. define reconciliation and correctness evidence;
7. attach deletion predicates to temporary artifacts;
8. state unavoidable residual debt instead of hiding it;
9. leave the resulting system able to make its next architecture decision normally.

## Tie-breakers

When evidence does not clearly separate two paths, prefer:

1. fewer irreversible effects;
2. less user/downstream pain;
3. less time with multiple authorities;
4. cleaner final ownership;
5. fewer permanent compatibility obligations;
6. easier verification;
7. lower recurring operational tax;
8. lower implementation cost;
9. faster implementation.

## Machine assistance

`trapt-in-the-closet-3/tools/least-piss-path.py` accepts ordinal evidence-backed scores and applies the tier ordering lexicographically. It is not authorized to invent scores. Each score must be derived from evidence or explicitly marked as an inference before use.
