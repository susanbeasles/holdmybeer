# Authorized VCS Tool Contract

Agents must not execute raw Git commands or call provider mutation APIs directly. Repository access is exposed through an approved semantic VCS abstraction.

The boundary is intentionally **read-rich and write-narrow**. Agents may receive deep forensic and historical inspection capabilities while durable repository mutations remain constrained to explicit high-level operations.

The implementation behind these operations may use Git CLI, libgit2, JGit, GitHub/GitLab APIs, MCP, GraphQL, REST, or another transport. That implementation detail is not visible to or selectable by the agent.

## Capability classes

Every VCS operation belongs to one of four classes:

1. **Inspection** — read repository, object, ref, PR, provider, and history state. No durable mutation.
2. **Ephemeral analysis** — create disposable analysis state such as a temporary checkout, merge simulation, synthetic index, or patch application. Must not move durable refs or publish objects.
3. **Owned-workspace mutation** — modify only the agent-owned working tree/index or create signed commits on the authorized work branch through fixed semantic operations.
4. **Publication** — update remote repository state through tightly constrained operations such as publishing the owned branch, opening a PR, or merging an eligible PR.

Inspection and ephemeral analysis should be broad enough for triage, incident response, provenance analysis, and conflict resolution. Publication remains narrow.

# Inspection capabilities

Inspection operations may be invoked without mutation approval when the task requires them. They should return structured data plus stable identifiers so later operations can cite exact evidence.

## Repository state

### `repo.status()`
Return repository root, current branch or detached state, cleanliness, staged/unstaged/untracked paths, upstream state, configured remotes, and active worktree identity.

### `repo.primaryBranch()`
Return the configured primary branch, canonical remote, and current resolved remote tip.

### `repo.remotes()`
Return configured remotes, fetch URLs, push URLs when policy permits disclosure, default remote, and provider identity.

### `repo.refs(namespace?, pattern?)`
List refs without moving them. Support bounded namespaces such as heads, remotes, tags, pull refs, notes, and replace refs. Return ref name, resolved object ID, peeled target when applicable, and symbolic-ref target.

### `repo.resolve(revision)`
Resolve a revision expression or provider reference to an immutable object ID. Return ambiguity and missing-object errors explicitly.

### `repo.remoteTip(branch, remote?)`
Resolve the current remote branch tip from the provider or fetched remote state without mutating local work.

## History and ancestry

### `repo.log(query)`
Return bounded commit history with structured filters: revision range, paths, author, committer, time window, first-parent, merges-only, no-merges, topology order, max count, and cursor pagination.

Do not impose a blanket prohibition on history traversal when history analysis is the task. Require explicit bounds or pagination instead.

### `repo.commit(oid)`
Return normalized commit metadata: tree ID, parent IDs, author identity/time, committer identity/time, message, encoding, signature presence, signature verification result, and provider-associated identity metadata when available.

### `repo.commitRaw(oid)`
Return the canonical raw commit object bytes or lossless parsed representation needed for forensic analysis, including exact author/committer headers, timestamps, timezone offsets, optional signature headers, and parent ordering.

This operation is read-only and is appropriate for spoofing/tampering investigations.

### `repo.parents(oid)`
Return direct parents in canonical order.

### `repo.ancestors(oid, options?)`
Traverse ancestry with explicit bounds. Support first-parent mode, maximum depth/count, stop OIDs, and path filtering.

### `repo.descendants(oid, refs?)`
Return known descendant commits reachable from the supplied bounded ref set.

### `repo.isAncestor(ancestor, descendant)`
Return whether one commit is reachable from another and provide the shortest supporting ancestry path when practical.

### `repo.mergeBase(a, b, all?)`
Return one or all merge bases for two revisions.

### `repo.forkPoint(branch, upstream?)`
Return the likely fork point using ancestry and reflog/provider evidence when available, with confidence/evidence rather than silently guessing.

### `repo.rangeDiff(oldBase, oldTip, newBase, newTip)`
Compare two commit series semantically to detect rewritten, reordered, added, dropped, or materially changed commits.

### `repo.patchId(oid, stable?)`
Return a stable patch identity for change-equivalence analysis independent of commit metadata.

### `repo.equivalentChanges(rangeA, rangeB)`
Compare commit ranges using patch identity and tree deltas to identify cherry-picks, rebases, duplicated changes, and rewritten-equivalent commits.

## File provenance and blame

### `repo.blame(path, revision?, range?, options?)`
Return line provenance with originating commit, author/committer metadata, source path, source line, boundary commit status, and rename/copy-following behavior when supported.

### `repo.blameTrace(path, line, revision?, depth?)`
Trace a line or hunk backward across blame origins, renames, and relevant parent commits to explain how the current content evolved.

### `repo.fileHistory(path, options?)`
Return bounded history for a path with rename detection and optional content-following.

### `repo.lastChange(path, revision?)`
Return the most recent commit affecting the path plus relevant diff metadata.

### `repo.deletedPathHistory(path, options?)`
Locate historical versions of a deleted or renamed path.

## Objects and trees

### `repo.object(oid)`
Return object type, size, and bounded decoded metadata. Blob contents should be subject to secret/redaction and size policy.

### `repo.objectRaw(oid)`
Return lossless raw object content when forensic analysis explicitly requires it and policy permits it.

### `repo.tree(oid, path?, recursive?, depth?)`
List tree entries with mode, type, object ID, and path.

### `repo.blob(oid|revisionPath, range?)`
Read bounded file/blob content with binary detection, size caps, and secret-handling policy.

### `repo.diff(base, head, options?)`
Return structured file and hunk changes. Support rename/copy detection, whitespace modes, binary summaries, path filters, and merge diff modes.

### `repo.diffTree(a, b, options?)`
Compare trees directly without requiring branch checkout.

## Ref and reflog forensics

### `repo.reflog(ref?, options?)`
Read local reflog entries when present: old/new OIDs, actor identity, timestamp, operation message, and source worktree. Never create or rewrite reflog entries.

### `repo.refHistory(ref, options?)`
Build a best-effort history of ref movement using local reflogs, provider events/audit logs, PR events, and known fetch state. Return source and confidence for each transition.

### `repo.danglingObjects(options?)`
Enumerate unreachable/dangling commits, trees, tags, or blobs visible to the local object database, with bounds. This is forensic inspection only; it must not prune or recover refs automatically.

### `repo.reachability(oid, refs?)`
Return which supplied refs can reach an object and whether the object is currently unreachable from the selected durable refs.

## Identity, signature, and provenance forensics

### `repo.verifyCommit(oid)`
Verify cryptographic commit signature when present and return signer identity, key/fingerprint, trust/verification status, verification mechanism, and failure reason.

### `repo.verifyTag(tag|oid)`
Verify annotated tag signatures and tag-object provenance.

### `repo.identityEvidence(oid)`
Return a provenance bundle containing:
- author name/email/time/timezone;
- committer name/email/time/timezone;
- signature identity and verification result;
- provider actor associated with push/PR/merge when available;
- verified-email/account association when provider exposes it;
- branch/ref event provenance when available;
- discrepancies between Git metadata and provider-side identity.

Do not treat author or committer strings as authenticated identity.

### `repo.detectMetadataAnomalies(query)`
Analyze bounded commits for suspicious metadata such as impossible chronology, unusual timezone shifts, author/committer divergence, unverifiable signatures, identity changes, malformed headers, repeated foreign identities, or provider/Git identity mismatch.

Return observations and evidence, not accusations. Metadata anomalies alone do not prove malicious activity.

### `repo.providerEvents(query)`
Read repository/provider audit events available to the current credentials, such as pushes, force-updates, branch creation/deletion, PR merges, merge actor, tag events, and workflow identity. This is provider-specific and read-only.

### `repo.compareProvenance(oids)`
Compare identity, signature, provider event, parentage, and timing evidence across commits to aid incident reconstruction.

## Pull request and review inspection

### `repo.pr(number|branch)`
Return PR metadata, base/head immutable OIDs, checks, reviews, comments, merge state, linked tickets, requested reviewers, and provider event evidence.

### `repo.prDiff(pr, version?)`
Return the PR diff for current or provider-retained historical versions when supported.

### `repo.prTimeline(pr, options?)`
Return review, push, synchronize, label, approval, dismissal, merge, and status events with actor/time evidence.

### `repo.reviewThreads(pr, state?)`
Return review threads, file/line anchors, resolution state, authors, and responses.

# Ephemeral analysis capabilities

These operations may alter disposable analysis state but must not move durable refs, publish objects, alter protected/shared workspaces, or rewrite the user's working tree.

Prefer isolated temporary clones, worktrees, in-memory indexes, or library-level tree operations.

### `repo.analysisWorkspace(spec)`
Create or acquire an isolated disposable workspace at an immutable revision. Return an analysis workspace ID. It must not become a durable branch by default.

### `repo.releaseAnalysisWorkspace(id)`
Destroy disposable analysis state. It must not delete user work or durable refs.

### `repo.simulateMerge(base, ours, theirs, options?)`
Perform a three-way merge calculation without updating a durable ref. Return cleanly merged paths, conflict paths, stages/base-ours-theirs blobs, rename/add-delete conflicts, and synthetic result tree when available.

### `repo.conflictDetails(base, ours, theirs, paths?)`
Return per-conflict semantic information including common ancestor content, both sides, relevant history, renames, and commits responsible for each side.

### `repo.suggestConflictResolution(base, ours, theirs, path)`
Produce a proposed forward-moving resolution with evidence from ancestry, intent, tests, and surrounding code. This operation must not publish or move refs.

### `repo.applyPatchEphemeral(workspace, patch|commit, options?)`
Apply a patch/cherry-pick-like transformation only inside disposable analysis state to test whether a historical change composes cleanly.

### `repo.replaySeriesEphemeral(workspace, commits, onto)`
Replay a commit series in disposable state to identify ordering dependencies and conflicts. Must not update a durable ref.

### `repo.testResolutionEphemeral(workspace, resolution)`
Materialize a proposed conflict resolution in isolated state so tests/typechecks/builds can validate it before any owned-workspace mutation.

# Owned-workspace mutation capabilities

Only these semantic mutations are authorized for normal engineering work. The agent never receives arbitrary Git flags or ref-update primitives.

### `repo.prepareWorkspace()`
Purpose: establish a pristine starting state before work begins.

Required behavior:
- Verify repository identity and root.
- Fetch the configured remote through policy-controlled implementation.
- Detect dirty, staged, untracked, or divergent state.
- Preserve user work by default.
- Refuse destructive cleanup unless the wrapper has an explicit startup-only recovery policy.
- Return a clean/blocked result with evidence.

The agent must not choose reset, stash, clean, checkout-discard, or similar low-level behavior.

### `repo.createWorkBranch(ticket, kind, suffix?, agent?)`
Purpose: create the dedicated owned work branch.

Required behavior:
- Resolve the current remote primary-branch tip.
- Create the new branch from that exact immutable tip.
- Enforce branch naming policy.
- Refuse collisions unless the existing branch is positively identified as the same authorized owned work branch.

### `repo.editWorkspace(files|patch)`
Purpose: modify files only in the authorized owned worktree through the agent's normal file-editing capability.

This operation must never update refs, repository config, hooks, object alternates, replace refs, or hidden Git metadata.

### `repo.stage(paths?)`
Purpose: stage intended work.

Required behavior:
- Default to changed files within task scope.
- Reject secrets, generated junk, repository metadata, or files prohibited by policy.
- Return exact staged files and a staged diff summary.

### `repo.commitChange(type, scope, ticket, description)`
Purpose: create a signed Conventional Commit on the authorized owned branch.

Required behavior:
- Construct the message from validated structured fields.
- Enforce repository commitlint rules.
- Require the approved signing identity/key.
- Refuse empty commits unless explicitly supported by policy.
- Return commit OID and verification state.

### `repo.syncPrimary()`
Purpose: synchronize the owned work branch with the latest remote primary branch.

Required behavior:
- Resolve/fetch the latest remote primary tip.
- Determine the repository-approved synchronization strategy internally.
- Apply only that strategy to the owned branch.
- Never rewrite protected/shared branches.
- Stop on semantic conflicts and return conflict details.
- Never apply blanket ours/theirs resolution.
- Any history-rewriting implementation detail remains hidden behind this semantic operation and must be lease/protection constrained.

### `repo.applyResolvedConflict(resolution)`
Purpose: apply an explicitly selected, evidence-backed conflict resolution to the authorized owned workspace/branch.

Required behavior:
- Accept structured per-path resolutions, not arbitrary ref commands.
- Verify the base/ours/theirs OIDs still match the analysis that produced the resolution.
- Refuse stale resolutions.
- Return resulting tree/diff evidence.

# Publication capabilities

### `repo.publishWorkBranch()`
Publish only the current authorized owned work branch.

Required behavior:
- Refuse protected/shared branch targets.
- Determine safe provider/Git transport internally.
- Never expose unconditional force-update behavior to the agent.
- Verify expected remote old OID before any non-fast-forward owned-branch update.
- Return old/new remote OIDs and provider evidence.

### `repo.openPullRequest(title, body, tickets, reviewers?, reviewerAgents?)`
Create a PR targeting the configured primary branch and enforce the PR contract.

### `repo.updatePullRequest(pr, fields)`
Allow only authorized PR metadata changes, ready-for-review transition, reviewer requests, and comments.

### `repo.respondToReview(pr, thread, response?, resolution?)`
Post evidence-backed review responses and resolve threads only after the concern is addressed or explicitly justified.

### `repo.mergeEligiblePullRequest(pr)`
Merge only when required CI, approvals, review threads, branch protection, mergeability, and target-branch checks pass immediately before merge.

The wrapper selects the repository-approved merge method. The agent never receives a raw merge/ref-update primitive.

# Explicitly forbidden direct capabilities

Agents are never authorized to invoke an equivalent raw mutation path, including:

- Git CLI write commands.
- `git update-ref`, `symbolic-ref` writes, ref-file writes, or direct edits beneath `.git`.
- arbitrary checkout/reset/restore/clean/stash/rebase/merge/cherry-pick/revert commands outside semantic wrappers;
- arbitrary commit-tree, mktag, hash-object write, index manipulation, or replace/graft writes;
- shell aliases/scripts that execute Git writes outside the approved wrapper;
- direct GitHub/GitLab/Bitbucket mutation APIs;
- `gh`, `glab`, or provider CLI mutation commands;
- unrestricted MCP repository-write tools;
- raw GraphQL/REST mutations;
- direct branch/tag deletion, creation, reassignment, or force-update;
- branch-protection changes, manufactured approvals, CI bypasses, or hidden administrator merge paths.

Read-only low-level implementation may exist behind approved inspection tools. The agent does not receive a generic `git(args)` or `provider.request(method, path, body)` escape hatch.

If an authorized operation is unavailable, the agent must stop that mutation step and report the missing capability. It must not fall back to raw Git or provider APIs.

# Tool design requirements

Approved VCS tools should:

- accept semantic intent, never arbitrary command strings;
- separate inspection, ephemeral analysis, owned-workspace mutation, and publication permissions;
- scope authorization to repository, workspace, branch, and operation;
- return immutable object IDs and provider event IDs for auditability;
- expose exact evidence needed to reproduce conclusions;
- support bounded pagination rather than arbitrary history dumps;
- redact secrets and enforce blob-size limits;
- verify TOCTOU-sensitive operations against expected OIDs before mutation;
- make dangerous primitives impossible to express in the agent-facing schema;
- emit structured audit logs for every mutation and relevant forensic read;
- allow policy to grant an incident responder broader read access without granting broader write access.

# Recommended role profiles

## Git triage agent

Grant:
- repository state;
- refs/resolve;
- bounded log and ancestry;
- blame/blameTrace/fileHistory;
- diffs/trees/blobs;
- PR inspection;
- merge-base/patch-id/equivalentChanges.

Deny publication by default.

## Incident responder agent

Grant all triage reads plus:
- raw commit/object inspection;
- reflog/refHistory;
- dangling/reachability analysis;
- signature verification;
- identityEvidence;
- metadata anomaly detection;
- provider audit events;
- provenance comparison.

Grant ephemeral analysis workspaces when useful. Deny publication unless separately authorized for remediation.

## PR conflict resolver agent

Grant:
- refs/resolve/log/ancestry;
- mergeBase/forkPoint/rangeDiff/patchId;
- diffs/file history/blame;
- PR timeline and review threads;
- `analysisWorkspace`;
- `simulateMerge`;
- `conflictDetails`;
- `suggestConflictResolution`;
- ephemeral patch/series replay/testing.

If it is also authorized to modify the owned PR branch, additionally grant `applyResolvedConflict`, validation tools, `commitChange`, `syncPrimary`, and `publishWorkBranch`. It still does not receive raw ref mutation.
