# Fourth Option — Reversible Deferral Protocol

Use this protocol in addition to the Three-Option Decision Protocol when uncertainty has genuine information value and a low-cost neutral architecture can preserve future choice.

## Option 4 is not "do nothing"

The fourth option is **Preserve Optionality**: implement the minimum correct architecture needed today, deliberately postpone one expensive or irreversible choice, instrument the missing evidence, and establish an objective forcing function for the next decision.

A valid Option 4 must:

1. satisfy present acceptance criteria;
2. preserve domain correctness;
3. isolate uncertainty behind a narrow stable seam;
4. increase information during the holding period;
5. define a bounded holding cost;
6. define an objective decision gate;
7. pre-plan both exits;
8. leave both exits free of material refactor or architectural-compromise tax introduced by the deferral itself.

## Required fields

- exact decision deferred;
- reason information will improve;
- neutral implementation now;
- 3-7 implementation steps;
- evidence collection plan;
- forcing predicate;
- maximum deferral horizon;
- Left exit path and tax;
- Right exit path and tax;
- holding cost;
- temporary artifacts with deletion conditions;
- kill criteria;
- reversibility proof;
- cost, risk and confidence.

## Validity test

Reject Option 4 if any answer is `yes`:

- Does waiting make a required migration monotonically more expensive?
- Does the middle state introduce a false domain abstraction?
- Does either future require undoing persisted state created only for the deferral?
- Does it duplicate core business logic across both potential futures?
- Is there no measurable signal likely to improve the decision?
- Is there no objective condition forcing re-evaluation?
- Can the holding pattern silently become permanent?
- Can the capacity/security/compliance deadline arrive before useful evidence?

## Recommendation behavior

The specialist may recommend Option 4 over Options 1-3 when it has the highest expected value under uncertainty. "We do not know enough" by itself is insufficient; the option must explain exactly how waiting creates knowledge and what clean architecture buys that time.
