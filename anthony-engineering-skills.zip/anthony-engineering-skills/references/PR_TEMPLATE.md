# <TICKET> - <Short description>

Tickets / artifacts:
- <Jira URL>
- <Additional relevant links>

## What

<Substantive description of what changed.>

## How

<Implementation approach, techniques, alternatives considered, and tradeoffs.>

## Why

<Context, rationale, benefits, downsides, risks, and why this choice wins against the alternatives.>

## Reviewer context

<Information that lets a reviewer understand the mental model quickly: affected domains, constraints, compatibility, migrations, rollout/rollback, observability, QA steps, intentionally unchanged behavior, and areas deserving extra scrutiny.>

## Validation

- [ ] Acceptance criteria satisfied
- [ ] Automated tests pass
- [ ] >=95% coverage for new/materially changed behavior
- [ ] Manual QA steps added to ticket
- [ ] Lint passes
- [ ] Formatter/Prettier passes
- [ ] Typecheck passes
- [ ] Production build passes
- [ ] Required security/repository checks pass
- [ ] CI green
