# Agent Evidence Standard

Every investigative skill in this bundle follows the same evidence discipline.

## Evidence classes

1. **Immutable fact** — object ID, tree ID, parent ID, blob ID, signature result, test output, file content at a specific commit.
2. **Derived fact** — merge base, reachability, patch equivalence, blame origin, timeline ordering, reproducible race observation.
3. **Inference** — a conclusion supported by facts but not itself directly encoded in repository state.
4. **Hypothesis** — a plausible explanation not yet distinguished from alternatives.

Never present class 3 or 4 as class 1 or 2.

## Required claim shape

Every material conclusion must be expressible as:

```json
{
  "claim": "...",
  "confidence": 0.0,
  "classification": "immutable_fact|derived_fact|inference|hypothesis",
  "evidence": [
    {
      "kind": "commit|blob|diff|blame|signature|timeline|test|race_run|other",
      "locator": "immutable or reproducible locator",
      "observation": "what the evidence demonstrates"
    }
  ],
  "alternatives_considered": ["..."],
  "disconfirming_evidence": ["..."]
}
```

## Determinism rules

- Resolve symbolic names to immutable object IDs before analysis.
- Capture the primary branch remote tip at investigation start.
- Record command/tool version and relevant options in evidence packets.
- Use explicit bounds for history traversal; expand only when evidence requires it.
- Prefer graph, tree, blob, signature, and test evidence over commit-message interpretation.
- Never infer authenticated identity from Git author/committer strings alone.
- Never call an absence of evidence proof that an event did not occur.
- When confidence is below 0.8, label the result as an unresolved hypothesis unless the task explicitly requests speculative leads.
