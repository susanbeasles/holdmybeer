# Three-Option Decision Protocol

Use this protocol whenever a specialist is asked to recommend architecture, UX, API, or data-model direction under uncertainty.

## Objective

Reduce open-ended agent improvisation. Produce exactly three materially different executable paths grounded in evidence from the current system and historical context.

## Mandatory option set

1. **Conservative** — minimum structural change; lowest migration and organizational risk.
2. **Recommended** — best expected long-term outcome under current evidence; default choice.
3. **Strategic** — larger structural investment justified only if stated assumptions and scale horizon hold.

Do not return three cosmetic variants of the same idea.

## Every option must include

- desired end state in one sentence;
- exact first 3-7 implementation steps;
- components/domains/tables/contracts expected to change;
- migration and compatibility strategy;
- expected behavior under load and partial failure;
- observability needed to prove it works;
- security/privacy implications;
- operational burden introduced or removed;
- reversible decisions vs one-way doors;
- known unknowns and assumptions;
- explicit stop conditions or evidence that would invalidate the option;
- relative cost: S/M/L/XL;
- relative risk: low/medium/high;
- confidence from 0.0-1.0.

## Recommendation rule

Choose exactly one recommended option. Explain why it dominates the alternatives under the evidence available today. Do not choose the strategic option merely because it is architecturally elegant.

## Unknowns

Unknowns are not an excuse to ask the operator by default. Classify each unknown:

- `must-know-before-change`: irreversible/security/compliance/data-loss risk;
- `can-measure`: resolve by instrumentation, benchmark, query, trace, or experiment;
- `can-contain`: proceed behind compatibility boundary, feature flag, shadow path, dual read/write, or isolated interface;
- `non-material`: record and proceed.

Ask the operator only for unresolved `must-know-before-change` facts that cannot be derived from available evidence.
