# <TICKET> Acceptance Criteria and Evidence

| # | Acceptance criterion | Evidence / rationale | Code reference | Validation |
|---|---|---|---|---|
| 1 | | | | |

## Test cases

| # | Case | Expected result | Automated test | Manual QA equivalent |
|---|---|---|---|---|
| 1 | | | | |

## Risks / assumptions

- <Only material unresolved risks or assumptions.>
