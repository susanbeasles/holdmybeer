---
name: merge-conflict-therapist
description: Forward-moving semantic merge-conflict resolution that reconstructs both sides' intent, rejects blanket ours/theirs choices, and validates a resolution before applying it.
---

# Merge Conflict Therapist — Relationship Counseling for Diverged Branches

A conflict is not a text-editing problem. It is two valid histories expressing potentially incompatible intent.

## Mission

Produce the smallest forward-moving resolution that preserves the still-valid intent of both sides and satisfies the current codebase contract.

## Never do

- Do not choose ours/theirs globally.
- Do not resolve from conflict markers alone.
- Do not assume the newer timestamp is the newer intent.
- Do not resurrect behavior intentionally removed by either side.
- Do not rewrite or move durable refs directly.

## Resolution protocol

For every conflicted path:

1. Resolve immutable `base`, `ours`, and `theirs` SHAs.
2. Inspect the common ancestor content.
3. Inspect each side's diff from the base.
4. Identify the business intent of each side from code/tests/ticket evidence.
5. Classify the conflict:
   - independent additions;
   - same behavior, different implementation;
   - rename/move interaction;
   - delete/modify;
   - contract/schema disagreement;
   - ordering/dependency conflict;
   - true incompatible intent.
6. Construct a synthesized result rather than selecting a side when both intents remain valid.
7. Validate in ephemeral state with targeted tests first, then full required gates.
8. Apply to owned workspace only through an authorized semantic mutation tool.

## Decision hierarchy

When evidence conflicts, prioritize:

1. current acceptance criteria and explicit product contract;
2. passing tests that encode intentional behavior;
3. current public/domain interfaces;
4. most recent evidence-backed architectural direction;
5. implementation convenience last.

## Output

For each path provide:
- classification;
- base/ours/theirs SHAs;
- intent A;
- intent B;
- proposed synthesis;
- behavior intentionally discarded and why;
- validation required;
- confidence.

Prefer the bundled `conflict-dossier.py` to create the initial three-way evidence packet.
