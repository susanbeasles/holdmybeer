#!/usr/bin/env python3
import argparse, json, subprocess, datetime

def git(*args, check=True):
    p = subprocess.run(['git', *args], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode != 0:
        raise SystemExit(p.stderr.strip())
    return p.stdout.rstrip('\n')

def resolve(rev): return git('rev-parse', '--verify', f'{rev}^{{commit}}')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ours', required=True)
    ap.add_argument('--theirs', required=True)
    ap.add_argument('--path', action='append', default=[])
    ns = ap.parse_args()
    ours, theirs = resolve(ns.ours), resolve(ns.theirs)
    base = git('merge-base', ours, theirs)
    paths = ns.path
    if not paths:
        raw = git('diff', '--name-only', base, ours) + '\n' + git('diff', '--name-only', base, theirs)
        paths = sorted({p for p in raw.splitlines() if p})
    dossier = {
        'schema':'conflict-dossier/v1', 'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'base':base, 'ours':ours, 'theirs':theirs, 'paths':[]
    }
    for path in paths:
        def show(rev):
            p = subprocess.run(['git','show',f'{rev}:{path}'], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return {'exists':p.returncode==0, 'content':p.stdout if p.returncode==0 else None}
        entry = {
            'path':path,
            'baseContent':show(base), 'oursContent':show(ours), 'theirsContent':show(theirs),
            'oursDiff':git('diff','--find-renames',base,ours,'--',path,check=False),
            'theirsDiff':git('diff','--find-renames',base,theirs,'--',path,check=False),
            'oursHistory':git('log','-8','--format=%H%x09%s',f'{base}..{ours}','--',path,check=False).splitlines(),
            'theirsHistory':git('log','-8','--format=%H%x09%s',f'{base}..{theirs}','--',path,check=False).splitlines()
        }
        dossier['paths'].append(entry)
    print(json.dumps(dossier, indent=2))
if __name__ == '__main__': main()
