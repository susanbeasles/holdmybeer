#!/usr/bin/env python3
"""Rank normalized historical/context evidence into machine-readable signal groups.

Input: JSONL records with fields such as:
  source_type, timestamp, status, claim, locator, corroborates, contradicts
Output: JSON summary to stdout.
"""
from __future__ import annotations
import argparse, json, math, sys
from datetime import datetime, timezone

BASE = {
    "code": 1.00, "test": 1.00, "schema": 1.00, "runtime": 1.00, "api_contract": 0.95,
    "adr": 0.92, "rfc": 0.88, "merged_pr": 0.85, "jira": 0.72, "confluence": 0.65,
    "comment": 0.45, "proposal": 0.40,
}
STATUS = {"implemented":1.0,"accepted":0.95,"planned":0.78,"proposed":0.60,"unknown":0.50,"superseded":0.25,"reverted":0.18}

def parse_time(s):
    if not s: return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception: return None

def recency(ts, now):
    if not ts: return 0.75
    days = max(0.0, (now-ts).total_seconds()/86400)
    # slow half-life: historical decisions remain useful, but decay.
    return 0.55 + 0.45 * math.exp(-days/730.0)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("path", nargs="?", default="-"); args=ap.parse_args()
    fh=sys.stdin if args.path=="-" else open(args.path, encoding="utf-8")
    now=datetime.now(timezone.utc); out=[]
    for i,line in enumerate(fh,1):
        line=line.strip()
        if not line: continue
        r=json.loads(line); st=(r.get("source_type") or "unknown").lower(); status=(r.get("status") or "unknown").lower()
        ts=parse_time(r.get("timestamp"));
        if ts and ts.tzinfo is None: ts=ts.replace(tzinfo=timezone.utc)
        score=BASE.get(st,0.50)*STATUS.get(status,0.50)*recency(ts,now)
        if r.get("corroborates"): score=min(1.0, score+0.06)
        if r.get("contradicts"): score=max(0.0, score-0.04)
        out.append({**r,"signal_score":round(score,4),"line":i})
    out.sort(key=lambda x:(x["signal_score"], x.get("timestamp") or ""), reverse=True)
    print(json.dumps({"count":len(out),"signals":out}, indent=2))
if __name__=="__main__": main()
