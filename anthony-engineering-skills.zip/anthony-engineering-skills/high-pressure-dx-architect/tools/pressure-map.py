#!/usr/bin/env python3
"""Repository architecture pressure-map heuristics. No external deps."""
from pathlib import Path
import argparse, json, re
SKIP={'.git','node_modules','dist','build','.next','coverage','vendor'}
PAT={
 'network':re.compile(r'\b(fetch\(|axios\.|http\.|https\.|requests\.|grpc|GraphQL|useQuery|useMutation)\b'),
 'queue':re.compile(r'\b(queue|kafka|sqs|pubsub|consumer|producer|enqueue|dequeue)\b',re.I),
 'retry':re.compile(r'\b(retry|backoff|dead.?letter|dlq|idempot)\b',re.I),
 'cache':re.compile(r'\b(redis|cache|memoiz|invalidate)\b',re.I),
 'concurrency':re.compile(r'\b(Promise\.all|goroutine|asyncio|thread|mutex|semaphore|lock\b)\b',re.I),
 'global_state':re.compile(r'\b(createContext|redux|zustand|mobx|globalThis|singleton)\b'),
}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('root',nargs='?',default='.');a=ap.parse_args();root=Path(a.root).resolve();rows=[]
 for p in root.rglob('*'):
  if not p.is_file() or any(x in SKIP for x in p.parts):continue
  if p.suffix.lower() not in {'.ts','.tsx','.js','.jsx','.py','.go','.rs','.java','.kt','.rb'}:continue
  try:s=p.read_text(errors='ignore')
  except:continue
  hits={k:len(v.findall(s)) for k,v in PAT.items()}; score=sum(hits.values())
  if score:rows.append({'file':str(p.relative_to(root)),'pressure_score':score,**hits})
 rows.sort(key=lambda x:x['pressure_score'],reverse=True)
 print(json.dumps({'root':str(root),'hotspots':rows[:100]},indent=2))
if __name__=='__main__':main()
