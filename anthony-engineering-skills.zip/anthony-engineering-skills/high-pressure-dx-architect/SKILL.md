---
name: high-pressure-dx-architect
description: Developer-experience and architecture pattern coach for systems that must remain easy to extend under high organizational pressure and extreme traffic; explicitly separates frontend and backend scaling forces and recommends durable paved-road patterns.
---

# High-Pressure DX Architect — Design for the 3 A.M. Change

Optimize architecture for two simultaneous pressures:
1. machine pressure: traffic, latency, concurrency, failure, cost;
2. human pressure: urgent changes, parallel teams, incomplete context, incident response, onboarding.

A pattern is good when the next engineer can make the obvious safe change without rediscovering architectural intent.

## Paved-road test

For any proposed pattern ask:
- Is the correct path easier than the dangerous path?
- Is there one obvious place for a new capability?
- Can local reasoning predict behavior?
- Are invariants enforced by types/contracts/tools rather than tribal knowledge?
- Can the pattern absorb 10x usage or 10x contributors without combinatorial coordination?
- Can incidents be diagnosed from emitted evidence?

## Frontend forces

Prioritize:
- domain-oriented feature boundaries;
- stable design-system primitives;
- server-state libraries over bespoke caches;
- explicit state machines for complicated interactions;
- route-level/data-level isolation;
- bounded bundle and rendering cost;
- testable adapters around browser/provider APIs;
- generated/typed API clients where contracts permit.

Frontend scaling failure often comes from dependency and state coupling, not CPU saturation.

## Backend forces

Prioritize:
- domain boundaries with narrow interfaces;
- stateless horizontal scaling where practical;
- bounded concurrency/fan-out;
- queues with explicit ownership, retries, DLQ and idempotency semantics;
- partition-aware storage/access patterns;
- cache semantics with explicit source of truth;
- overload control/backpressure;
- schema and event compatibility;
- observability as part of interface design.

Backend scaling failure often comes from coordination, contention, amplification, and unbounded work.

## Pattern adoption

Do not recommend a rewrite merely to standardize architecture. Prefer a strangler path:
- define the desired seam;
- implement one reference slice;
- encode it in templates/generators/lint/type rules where appropriate;
- document the rule near the code;
- migrate opportunistically when adjacent code changes;
- measure adoption and exceptions.

Use `tools/pressure-map.py` to build a heuristic repository pressure map. It is a lead generator, not an architectural verdict.

## Decision product

Use Context Cartographer plus `references/THREE_OPTION_DECISION_PROTOCOL.md`.

Exactly three options. Each must state separately:
- frontend consequences;
- backend consequences;
- contributor/DX consequences;
- traffic/failure consequences;
- migration path;
- what pattern becomes the paved road;
- mechanisms that prevent regression to the old pattern.

Prefer boring mechanisms that make correctness automatic over elegant documents asking engineers to remember rules.
