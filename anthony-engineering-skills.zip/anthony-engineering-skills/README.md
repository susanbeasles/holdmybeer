# Anthony Engineering Skills

A composable Agent Skills bundle for reliability-first, domain-driven, evidence-gated software delivery.

## Style label

**Reliability-First Domain-Driven Autonomous Engineering**

Secondary descriptors:
- Evidence-gated delivery
- Failure-oriented design
- Domain-driven architecture
- Composable clean code
- Low-interruption autonomy
- CI-complete ownership
- Reviewer-optimized change communication
- Capability-gated VCS discipline

## Skills

- `engineering-delivery/` — end-to-end task execution and acceptance-criteria workflow.
- `domain-driven-engineering/` — architecture, naming, function design, error handling, and implementation taste.
- `code-reviewer/` — high-signal, educational, line-level code review behavior.
- `git-pr-governance/` — branches, tickets, commits, PRs, review handling, and merge readiness.

The skills are intentionally composable. Load `engineering-delivery` for implementation work, and pair it with `domain-driven-engineering` and `git-pr-governance`. Load `code-reviewer` for review-only work.

## Policy normalization

The source rules contained two material ambiguities, so this bundle resolves them deterministically:

1. **Git authority**: agents have no raw Git or direct provider-mutation authority. Repository writes are exposed only through a narrow semantic VCS tool contract. The wrapper owns implementation details such as synchronization strategy and any lease-protected branch update. This removes the rebase/force-push contradiction from the agent entirely. See `references/VCS_TOOL_CONTRACT.md`.
2. **Coverage**: the source requires 95% coverage but does not define repository-wide vs changed scope. This bundle requires **>=95% coverage for new and materially changed executable behavior**, while also satisfying any stricter repository-wide threshold already enforced by CI. Do not perform unrelated legacy rewrites merely to raise historical global coverage unless that is part of the task.

The result is deny-by-default repository mutation with an auditable, preauthorized capability surface.

## Specialized deterministic agent skills

The bundle also includes five role-specific skills designed to reduce agent improvisation by forcing evidence-oriented workflows:

- **Blair Witch Triage — Cheater's Edition**: symptom-to-culprit narrowing using bounded blame/history/diff evidence.
- **Merge Conflict Therapist**: semantic three-way conflict reconstruction and forward-moving synthesis.
- **Minecraft Steve — History Excavator**: rename-aware origin and lineage archaeology.
- **History Reconstructor — Archaeologist**: commit/ref/provenance reconstruction and spoofed-metadata investigation.
- **Race Condition Drag Racer**: seeded concurrency stress, reproducible interleavings, and minimization.

See `references/CAPABILITY_PROFILES.md` and `references/AGENT_EVIDENCE_STANDARD.md` for the shared authorization and evidence model.

## Context and architecture advisory council

Five additional specialist skills turn incomplete historical context into bounded, executable technical decisions:

- **Context Cartographer — Requirements Without Story Time**: reconstructs current truth, historical intent, directional signals, stale assumptions, and the decision envelope from Jira, Confluence, Git, ADRs, code and tests.
- **Frontend UX Specialist — The Interface Is a State Machine**: treats interaction design as behavioral correctness across loading, failure, retry, accessibility, stale-data and high-traffic frontend conditions.
- **Backend UX Specialist — APIs Have Users Too**: designs caller-facing contracts around idempotency, stable errors, retries, pagination, compatibility, deadlines, observability and overload behavior.
- **High-Pressure DX Architect — Design for the 3 A.M. Change**: establishes paved-road patterns that survive both extreme traffic and high organizational/change pressure, with different reasoning for frontend and backend forces.
- **Data Model Specialist — Make Invalid States Expensive**: derives durable domain models, invariants, indexing/access patterns and migration plans from present behavior plus historical direction.

All four recommendation-producing specialists use `references/THREE_OPTION_DECISION_PROTOCOL.md`: exactly three materially different paths (conservative, recommended, strategic), with concrete implementation steps, unknown classification, migration strategy, load/failure behavior, observability, reversibility, invalidation evidence and a single selected recommendation.

### Context ingestion

The Context Cartographer is provider-neutral. Jira and Confluence access should be supplied through approved read-only connectors/capabilities. Git historical investigation should use the read-rich VCS capability surface rather than raw mutation primitives. Normalized evidence may be ranked with `context-cartographer/tools/context-ranker.py`; the weighting is intentionally a decision aid, never a replacement for source inspection.

## Optionality architecture

- **Optionality Architect — Kick the Can Without Kicking Yourself**: produces a fourth, deliberately deferred path when waiting can cheaply buy material information. It requires a neutral domain seam, bounded holding cost, machine-observable decision gate, maximum horizon, pre-planned Left/Right exits, and proof that neither future inherits material refactor or architecture tax from the deferral.

Use `references/FOURTH_OPTION_DEFERRAL_PROTOCOL.md` alongside the normal three-option protocol when the decision is genuinely underdetermined. The fourth option is valid only when waiting increases knowledge and both future paths remain clean.

## Damaged-system extraction

- **Trapt in the Closet 3 — Pissed on the Wrong Agent**: use when the architecture is already cornered and every credible exit imposes real damage. It ignores sunk cost, rejects catastrophic paths before scoring convenience, compares exactly three forward extractions, identifies who pays the unavoidable cost (the "piss radius"), concentrates temporary mess in one sacrificial layer, names the point of no return, and selects the path that leaves the cleanest recoverable end state.

Use `references/DAMAGED_SYSTEM_EXTRACTION_PROTOCOL.md` when Optionality Architect is no longer valid because waiting does not buy useful information or the system has already crossed irreversible boundaries. The bundled `least-piss-path.py` helper performs lexicographic harm ranking so catastrophic risk cannot be averaged away by convenience or speed.
