#!/usr/bin/env bash
set -euo pipefail
path=""
rev="HEAD"
max="40"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --path) path="$2"; shift 2 ;;
    --rev) rev="$2"; shift 2 ;;
    --max) max="$2"; shift 2 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done
[ -n "$path" ] || { echo "usage: excavate.sh --path PATH [--rev REV] [--max N]" >&2; exit 2; }
oid=$(git rev-parse --verify "${rev}^{commit}")
printf '{\n'
printf '  "schema": "history-excavation/v1",\n'
printf '  "revision": "%s",\n' "$oid"
printf '  "path": %s,\n' "$(python3 -c 'import json,sys; print(json.dumps(sys.argv[1]))' "$path")"
printf '  "history": '
git log "-$max" --follow --format='%H%x09%P%x09%aI%x09%cI%x09%s' -- "$path" | python3 -c '
import json,sys
rows=[]
for line in sys.stdin:
 p=line.rstrip("\n").split("\t",4)
 if len(p)==5: rows.append({"commit":p[0],"parents":p[1].split() if p[1] else [],"authored":p[2],"committed":p[3],"subject":p[4]})
print(json.dumps(rows))'
printf ',\n  "currentBlob": '
if blob=$(git rev-parse "${oid}:${path}" 2>/dev/null); then printf '"%s"' "$blob"; else printf 'null'; fi
printf '\n}\n'
