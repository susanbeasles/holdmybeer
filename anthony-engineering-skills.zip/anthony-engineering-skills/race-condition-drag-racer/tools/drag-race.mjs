#!/usr/bin/env node
import { spawn } from 'node:child_process';
import process from 'node:process';

const argv=process.argv.slice(2);
const val=(k,d)=>{const i=argv.indexOf(k);return i>=0?argv[i+1]:d};
const workers=Number(val('--workers','4'));
const iterations=Number(val('--iterations','20'));
const seed0=Number(val('--seed','1'));
const jitter=Number(val('--jitter-ms','25'));
const timeout=Number(val('--timeout-ms','30000'));
const sep=argv.indexOf('--');
if(sep<0 || sep===argv.length-1){console.error('usage: drag-race.mjs [opts] -- command [args...]');process.exit(2)}
const cmd=argv[sep+1], cmdArgs=argv.slice(sep+2);
function rng(seed){let x=seed>>>0;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return(x>>>0)/4294967296}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function one(seed,worker,iteration){
  const r=rng(seed ^ ((worker+1)*0x9e3779b1) ^ iteration);
  await sleep(Math.floor(r()*jitter));
  const start=process.hrtime.bigint();
  return await new Promise(resolve=>{
    const p=spawn(cmd,cmdArgs,{stdio:['ignore','pipe','pipe'],env:{...process.env,RACE_SEED:String(seed),RACE_WORKER:String(worker),RACE_ITERATION:String(iteration)}});
    let stdout='',stderr='',killed=false;
    const t=setTimeout(()=>{killed=true;p.kill('SIGKILL')},timeout);
    p.stdout.on('data',d=>stdout+=d); p.stderr.on('data',d=>stderr+=d);
    p.on('close',(code,signal)=>{clearTimeout(t);const ms=Number(process.hrtime.bigint()-start)/1e6;resolve({seed,worker,iteration,code,signal,timedOut:killed,durationMs:+ms.toFixed(3),stdout:stdout.slice(-8000),stderr:stderr.slice(-8000)})});
  });
}
let failed=0;
for(let iteration=0;iteration<iterations;iteration++){
  const seed=seed0+iteration;
  const results=await Promise.all(Array.from({length:workers},(_,w)=>one(seed,w,iteration)));
  for(const result of results){console.log(JSON.stringify({schema:'race-run/v1',...result}));if(result.code!==0)failed++;}
  if(failed) break;
}
process.exit(failed?1:0);
