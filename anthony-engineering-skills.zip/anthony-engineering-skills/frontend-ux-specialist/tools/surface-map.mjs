#!/usr/bin/env node
import fs from 'node:fs'; import path from 'node:path';
const root=path.resolve(process.argv[2]||'.'); const exts=new Set(['.tsx','.jsx','.ts','.js','.vue','.svelte']);
const pats={async:/\b(fetch|useQuery|useMutation|axios|loader|action)\b/g, loading:/\b(loading|isLoading|pending|isPending|Suspense)\b/gi,error:/\b(error|isError|catch|ErrorBoundary)\b/g, aria:/\b(aria-|role=|labelledby|describedby)\b/g, effect:/\buseEffect\s*\(/g, optimistic:/\boptimistic|onMutate|rollback\b/gi};
const rows=[]; function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(['node_modules','.git','dist','build','.next'].includes(e.name))continue; const p=path.join(d,e.name); if(e.isDirectory())walk(p); else if(exts.has(path.extname(e.name))){const s=fs.readFileSync(p,'utf8'); const m={}; for(const [k,r] of Object.entries(pats)){r.lastIndex=0;m[k]=[...s.matchAll(r)].length;} if(Object.values(m).some(Boolean))rows.push({file:path.relative(root,p),...m});}}}
walk(root); rows.sort((a,b)=>(b.async+b.effect+b.optimistic)-(a.async+a.effect+a.optimistic)); console.log(JSON.stringify({root,files:rows.length,surfaces:rows},null,2));
