---
name: domain-driven-engineering
description: Design and implement code using domain-driven boundaries, concise business naming, small composable functions, config-driven behavior, idempotency, explicit failure handling, and durable production architecture.
---

# Domain-Driven Engineering

## Architectural taste

Model software around recognizable business domains and entities rather than implementation mechanics.

A good entity is a business noun that immediately communicates a bounded concept, capabilities, properties, and responsibility. Prefer names such as `User`, `Message`, `Survey`, `SurveyResponse`, `Patient`, `Practice`, `Claim`, `Payment`, or other nouns native to the business.

A reader should gain meaningful context from names without needing deep knowledge of the repository.

## Domain boundaries

Favor modules, classes, namespaces, closures, services, repositories, and interfaces that align with a single business domain.

Keep domain logic near the domain that owns it. Do not create generic dumping-ground modules such as `utils`, `helpers`, or `common` when the behavior has a clear domain owner.

Separate concerns when they have different reasons to change. A boundary should be understandable in business terms, not only technical terms.

## Naming rules

Naming is an architectural tool. Treat it as part of correctness.

### Entities, variables, and models

Prefer a single-word domain noun.

Use two words only when the second word materially removes ambiguity.

Avoid conjunctions such as `And` or `Or` in names. A conjunction usually signals mixed responsibilities or an unclear abstraction.

### Functions and methods

Prefer `verb + domain noun` when the function is standalone:

- `calculateTotal`
- `submitSurvey`
- `processPayment`
- `dispatchEvent`
- `sendMessage`
- `discardDuplicateResponse`

The name should reveal the responsibility boundary: what action begins here and what responsibility ends here.

When the domain is already expressed by the containing class/module/namespace, remove redundant nouns:

- prefer `patient.enroll()` over `patient.enrollPatient()`;
- prefer `practice.scheduleAppointment()` over `practice.schedulePracticeAppointment()`;
- prefer `Claim.process()` over `Claim.processClaim()`.

## Function design

Write small, single-purpose, independently testable, composable functions.

Each function should:

- have one responsibility;
- expose one clear input contract and one clear output contract;
- avoid hidden mutation unless mutation is the explicit purpose of the operation;
- be deterministic when practical;
- be idempotent when the operation may be retried or duplicated;
- follow the same structural pattern as peer functions with the same responsibility;
- remain useful without accumulating boolean flags, mode switches, or special-case branches.

Prefer composition of focused functions over large orchestration blocks.

If a function grows multiple independent branches, multiple side effects, or multiple reasons to change, split it at the domain boundaries.

## Reuse and abstraction

If the same meaningful two or three lines of behavior appear repeatedly, evaluate a shared abstraction. Abstract repeated behavior, not merely repeated syntax.

Do not create abstractions in anticipation of hypothetical reuse. Wait until the common domain behavior is clear enough to name correctly.

Prefer configuration-driven behavior when the variability is data rather than genuinely different domain logic. Keep configuration typed, validated, explicit, and close to the owning domain.

## Failure-oriented design

Assume credible failures will eventually occur.

For external systems and asynchronous work, explicitly design for:

- timeout;
- retry;
- duplicate execution;
- partial success;
- malformed responses;
- stale data;
- missing data;
- out-of-order events;
- dependency unavailability;
- permission denial;
- concurrency;
- restart/recovery;
- poison messages or permanently failing work.

Do not silently swallow failures. Errors should preserve enough context to diagnose the domain operation without exposing secrets or sensitive data.

Use structured logs and metrics at meaningful domain boundaries. Log the business operation, relevant safe identifiers, outcome, and actionable failure context.

## Security and operational simplicity

Prefer secure-by-default designs with least privilege, narrow interfaces, explicit validation, and minimal exposed surface area.

Avoid architectural complexity that creates operational burden without buying meaningful correctness, scale, reliability, or maintainability.

Favor deterministic infrastructure/configuration and repeatable behavior over hidden manual steps.

## Quality checks

Before finishing implementation, ask:

- Can every major object/module be named as a clear business domain or supporting technical boundary?
- Does each function have one obvious job?
- Do names reveal intent without reading implementation details?
- Are repeated behaviors centralized at the correct domain level?
- Are credible failure modes handled explicitly?
- Is retry/duplicate behavior safe?
- Is the solution easier to extend by composition rather than by adding flags and branching?
- Is the implementation observable enough to diagnose production failure?
- Did we avoid unnecessary operational or computational burden?
