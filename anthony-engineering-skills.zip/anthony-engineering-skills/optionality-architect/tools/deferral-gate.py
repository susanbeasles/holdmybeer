#!/usr/bin/env python3
"""Evaluate deterministic forcing predicates for an architectural deferral window.

Input JSON example:
{
  "metrics": {"write_p95_rps": 2300, "partition_gb": 180, "writers": 1},
  "rules": [
    {"name": "scale-left", "metric": "write_p95_rps", "op": ">=", "value": 2000, "decision": "decide-left"},
    {"name": "multi-writer-right", "metric": "writers", "op": ">=", "value": 2, "decision": "decide-right"}
  ],
  "deadline": "2026-12-01T00:00:00Z",
  "observed_at": "2026-10-01T00:00:00Z"
}
"""
import argparse
import datetime as dt
import json
import operator
import sys

OPS = {
    ">": operator.gt,
    ">=": operator.ge,
    "<": operator.lt,
    "<=": operator.le,
    "==": operator.eq,
    "!=": operator.ne,
}


def parse_time(value: str) -> dt.datetime:
    value = value.replace("Z", "+00:00")
    return dt.datetime.fromisoformat(value)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("spec", help="Path to JSON decision-gate specification, or - for stdin")
    args = parser.parse_args()

    raw = sys.stdin.read() if args.spec == "-" else open(args.spec, "r", encoding="utf-8").read()
    spec = json.loads(raw)
    metrics = spec.get("metrics", {})
    triggered = []

    for rule in spec.get("rules", []):
        metric = rule["metric"]
        if metric not in metrics:
            continue
        op_name = rule["op"]
        if op_name not in OPS:
            raise ValueError(f"unsupported operator: {op_name}")
        if OPS[op_name](metrics[metric], rule["value"]):
            triggered.append({
                "name": rule.get("name", metric),
                "metric": metric,
                "observed": metrics[metric],
                "operator": op_name,
                "threshold": rule["value"],
                "decision": rule.get("decision", "forced-review"),
            })

    deadline_hit = False
    if spec.get("deadline"):
        observed = parse_time(spec.get("observed_at") or dt.datetime.now(dt.timezone.utc).isoformat())
        deadline_hit = observed >= parse_time(spec["deadline"])

    decisions = sorted({x["decision"] for x in triggered})
    if len(decisions) == 1:
        result = decisions[0]
    elif len(decisions) > 1:
        result = "forced-review"
    elif deadline_hit:
        result = "forced-review"
    else:
        result = "hold"

    print(json.dumps({
        "result": result,
        "triggered": triggered,
        "deadline_hit": deadline_hit,
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
