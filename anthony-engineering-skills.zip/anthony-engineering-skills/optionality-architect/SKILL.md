---
name: optionality-architect
description: Produce a fourth architectural option that deliberately defers an irreversible decision without accumulating refactor debt, architectural compromise, or hidden operational tax. Use when uncertainty is material but delay can cheaply buy information.
---

# Optionality Architect — Kick the Can Without Kicking Yourself

## Mission

Produce a **fourth option** when the current decision is underdetermined and there is a credible low-cost way to buy information before choosing a durable direction.

This is not procrastination, "do nothing", or a temporary hack. The fourth option is an engineered **optionality window**: a bounded, observable, reversible intermediate state that preserves clean exits to two or more future architectures.

The goal is to arrive at the next forced decision with **more evidence and no meaningful refactor tax**.

## Use this skill when

Use only when all are true:

1. two or more durable paths remain plausible;
2. a presently unknown fact is likely to materially change which path is best;
3. that fact can become knowable through time, traffic, instrumentation, adoption, experiments, external dependency maturity, or a bounded spike;
4. deferral can be implemented behind a stable boundary without corrupting the domain model or public contract;
5. carrying cost through the deferral window is materially lower than choosing wrong today.

Do **not** manufacture a fourth option when one durable path already dominates or when waiting increases security, compliance, data-loss, availability, or irreversible migration risk.

## Inputs

Consume, without operator narration when available:

- current repository behavior and architecture;
- acceptance criteria and business constraints;
- Context Cartographer evidence;
- Jira/Confluence/ADR historical direction;
- production usage and traffic evidence;
- schema and API compatibility constraints;
- the conservative, recommended, and strategic options already proposed;
- known unknowns from the decision protocol.

Treat historical intent as evidence, not authority. Current executable behavior wins unless there is strong evidence of an active migration or explicitly accepted target architecture.

## Core rule

A valid deferral option must preserve the invariant:

> **No future branch should require undoing today's temporary architecture before it can begin.**

If choosing Left later requires deleting an abstraction, rewriting persisted data, replacing a public contract, or unpicking duplicated business logic introduced solely for the deferral, the option is invalid unless that cost is explicitly negligible and mechanically removable.

## Method

### 1. Name the decision being deferred

Write one precise sentence:

`We are deferring the decision between <A> and <B> until <evidence> crosses <decision threshold>.`

Do not defer a vague "architecture direction". Identify the exact one-way-door or expensive choice.

### 2. Identify the information gain

For every uncertainty that justifies waiting, state:

- what is unknown;
- why it changes the decision;
- how it becomes observable;
- expected signal latency;
- minimum sample/evidence needed;
- what result favors Left;
- what result favors Right.

If waiting does not predictably increase information, do not recommend deferral.

### 3. Find the neutral seam

Create or reuse the smallest stable boundary that both future paths can honor.

Prefer, in order:

1. existing domain interface or contract;
2. narrow adapter/port around the uncertain dependency;
3. configuration-selected implementation;
4. event or queue boundary;
5. compatibility facade;
6. temporary dual-read or shadow execution when required for measurement.

The seam must represent a **real domain capability**, not an abstraction invented solely to hide indecision.

Avoid generic repositories, service-locator patterns, universal factories, speculative plugin systems, or "strategy" abstractions that merely relocate branching complexity.

### 4. Keep the middle state intentionally boring

The temporary state should contain only what is required to:

- satisfy today's acceptance criteria;
- expose the stable seam;
- collect decision evidence;
- protect compatibility;
- preserve rollback/reversibility.

Do not prematurely implement half of both futures.

### 5. Define the forcing function

The option is invalid without a **forced re-decision point**.

At least one must exist:

- date/time horizon;
- sustained traffic threshold;
- dataset/cardinality threshold;
- latency/error/cost threshold;
- adoption threshold;
- dependency capability/version milestone;
- compliance/security deadline;
- operational toil threshold;
- number of consumers or domains crossing a threshold.

Prefer an objective predicate over a calendar date.

Example:

`Re-decide when p95 writes exceed 2,000/s for 14 consecutive days OR partition size exceeds 250 GB OR a second independent writer is approved.`

### 6. Pre-write both exits

Describe the first 3-7 steps for **Left** and **Right** from the deferred state.

For each exit prove:

- existing persisted data remains valid or has a bounded online migration;
- public contracts remain compatible or have a planned version boundary;
- business logic is not duplicated;
- the neutral seam remains useful or can be mechanically collapsed;
- no history rewrite or destructive migration is required;
- rollout can be staged and observed.

If one exit becomes substantially harder because of the deferral, quantify the tax and reject the option if it is material.

### 7. Price the holding cost

Explicitly account for:

- extra runtime hops;
- duplicated reads/writes;
- storage overhead;
- observability cost;
- cognitive complexity;
- operational toil;
- temporary compatibility code;
- test matrix expansion;
- latency and reliability impact.

A valid option must have a bounded carrying cost and an owner/removal condition for every temporary mechanism.

### 8. Install evidence collection now

Do not merely say "monitor it". Specify:

- exact metric/event/query/trace;
- dimensions/cardinality;
- collection point;
- baseline;
- threshold;
- evaluation window;
- dashboard or machine-readable report;
- who/what performs re-evaluation.

Prefer measurements produced by the normal execution path over bespoke manual sampling.

## Fourth-option output contract

Return the following after the normal three options.

### Option 4 — Preserve Optionality

**Deferred decision:** exact Left-vs-Right decision.

**Why waiting has value:** the information expected to arrive and why it changes the choice.

**Neutral architecture now:** the smallest implementation that satisfies present requirements while preserving both exits.

**Implementation steps:** exactly 3-7 concrete steps.

**Evidence to collect:** exact measurements and thresholds.

**Decision gate:** objective predicate that forces re-evaluation.

**Maximum deferral horizon:** latest acceptable time/condition before a durable choice becomes mandatory.

**Left exit:** concrete next steps and estimated migration/refactor tax.

**Right exit:** concrete next steps and estimated migration/refactor tax.

**Holding cost:** runtime, operational, cognitive, storage and compatibility costs during the window.

**Temporary artifacts:** every temporary flag, adapter, dual path, table/column, metric or compatibility layer and its deletion condition.

**Failure modes:** ways the deferral itself can become dangerous or silently permanent.

**Kill criteria:** conditions that immediately invalidate the deferral and force one of the durable options.

**Reversibility proof:** why choosing either side later does not require paying architectural-compromise or refactor tax created by this option.

**Relative cost:** S/M/L/XL.

**Relative risk:** low/medium/high.

**Confidence:** 0.0-1.0.

## Decision rules

Prefer Option 4 over the current recommended option only when:

`expected cost of waiting + holding cost + exit tax < expected regret of choosing now`

and the expected information gain before the decision gate is material.

The calculation may be qualitative, but all terms must be discussed explicitly.

Do not select Option 4 merely because stakeholders are uncomfortable choosing.

## Hard prohibitions

Never use deferral to postpone:

- known security vulnerabilities;
- compliance deadlines;
- active data corruption or integrity risk;
- known availability hazards with meaningful blast radius;
- an already-required breaking change whose compatibility window is closing;
- migrations that become more expensive monotonically with every new row/event/customer;
- capacity limits likely to be hit before useful evidence can arrive.

Never introduce a knowingly wrong domain model as an "intermediate" state.

Never make the temporary seam more general than both candidate futures require.

Never leave a deferral without a machine-observable decision gate.

## Optional deterministic helper

Use `tools/deferral-gate.py` with a JSON decision specification to evaluate whether observed evidence has reached a configured forcing condition. The helper returns a machine-readable `hold`, `decide-left`, `decide-right`, or `forced-review` result. It is a decision aid; the thresholds must come from the architectural recommendation and evidence, never be invented by the tool.
