#!/usr/bin/env python3
"""Create and validate deterministic multi-agent task locks.

Lock files are Markdown with a machine-readable JSON object between markers:
<!-- TEAM_LOCK_JSON
{...}
TEAM_LOCK_JSON -->
"""
from __future__ import annotations

import argparse
import datetime as dt
import fnmatch
import json
import pathlib
import sys
from typing import Any

START = "<!-- TEAM_LOCK_JSON"
END = "TEAM_LOCK_JSON -->"


def read_lock(path: pathlib.Path) -> dict[str, Any]:
    text = path.read_text()
    try:
        body = text.split(START, 1)[1].split(END, 1)[0].strip()
        data = json.loads(body)
    except Exception as exc:
        raise ValueError(f"invalid lock {path}: {exc}") from exc
    data["_path"] = str(path)
    return data


def overlaps(a: str, b: str) -> bool:
    if a == b:
        return True
    # Conservative glob overlap detection for common ownership forms.
    literal_a = not any(c in a for c in "*?[")
    literal_b = not any(c in b for c in "*?[")
    if literal_a and literal_b:
        pa, pb = pathlib.PurePosixPath(a), pathlib.PurePosixPath(b)
        return pa == pb or pa in pb.parents or pb in pa.parents
    if literal_a:
        return fnmatch.fnmatch(a, b)
    if literal_b:
        return fnmatch.fnmatch(b, a)
    prefix_a = a.split("*", 1)[0].rstrip("/")
    prefix_b = b.split("*", 1)[0].rstrip("/")
    return prefix_a == prefix_b or prefix_a.startswith(prefix_b + "/") or prefix_b.startswith(prefix_a + "/")


def validate(lock_dir: pathlib.Path) -> int:
    locks = [read_lock(p) for p in sorted(lock_dir.glob("*.lock.md"))]
    active = [x for x in locks if x.get("status") in {"claimed", "blocked", "handoff-ready"}]
    problems: list[dict[str, str]] = []
    for i, left in enumerate(active):
        for right in active[i + 1 :]:
            for lp in left.get("owns", []):
                for rp in right.get("owns", []):
                    if overlaps(lp, rp):
                        problems.append({
                            "left": left.get("task", left["_path"]),
                            "right": right.get("task", right["_path"]),
                            "left_path": lp,
                            "right_path": rp,
                        })
    result = {"valid": not problems, "active_locks": len(active), "overlaps": problems}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not problems else 2


def claim(args: argparse.Namespace) -> int:
    args.lock_dir.mkdir(parents=True, exist_ok=True)
    path = args.lock_dir / f"{args.task}.lock.md"
    if path.exists():
        print(f"lock already exists: {path}", file=sys.stderr)
        return 2
    payload = {
        "task": args.task,
        "agent": args.agent,
        "role": args.role,
        "status": "claimed",
        "lease_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "owns": args.owns,
        "shared": args.shared,
        "dependencies": args.depends,
        "handoff": args.handoff,
    }
    path.write_text(
        f"# Lock: {args.task}\n\n{START}\n{json.dumps(payload, indent=2, sort_keys=True)}\n{END}\n"
    )
    return validate(args.lock_dir)


def main() -> int:
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("validate")
    v.add_argument("--lock-dir", type=pathlib.Path, default=pathlib.Path(".agent/team/locks"))
    c = sub.add_parser("claim")
    c.add_argument("task")
    c.add_argument("--agent", required=True)
    c.add_argument("--role", required=True)
    c.add_argument("--owns", action="append", default=[], required=True)
    c.add_argument("--shared", action="append", default=[])
    c.add_argument("--depends", action="append", default=[])
    c.add_argument("--handoff", default="")
    c.add_argument("--lock-dir", type=pathlib.Path, default=pathlib.Path(".agent/team/locks"))
    args = p.parse_args()
    if args.cmd == "validate":
        return validate(args.lock_dir)
    return claim(args)


if __name__ == "__main__":
    raise SystemExit(main())
