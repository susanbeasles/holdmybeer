#!/usr/bin/env python3
"""Render a compact JSON status report from team task locks and handoffs."""
from __future__ import annotations
import argparse, json, pathlib, re

START = "<!-- TEAM_LOCK_JSON"
END = "TEAM_LOCK_JSON -->"

def lock_data(p: pathlib.Path):
    t=p.read_text(); d=json.loads(t.split(START,1)[1].split(END,1)[0].strip()); d["file"]=str(p); return d

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--team-dir", type=pathlib.Path, default=pathlib.Path(".agent/team")); a=ap.parse_args()
    locks=[]
    for p in sorted((a.team_dir/"locks").glob("*.lock.md")):
        try: locks.append(lock_data(p))
        except Exception as e: locks.append({"file":str(p),"status":"invalid","error":str(e)})
    handoffs={p.stem for p in (a.team_dir/"handoffs").glob("*.md")} if (a.team_dir/"handoffs").exists() else set()
    out={"locks":locks,"handoffs":sorted(handoffs),"summary":{}}
    for x in locks: out["summary"][x.get("status","unknown")]=out["summary"].get(x.get("status","unknown"),0)+1
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=="__main__": main()
