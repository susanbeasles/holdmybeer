---
name: team-agentic-worldwide-org-maintainers
description: Operate a persistent multi-agent software delivery team with a single Lead and specialized UI, backend, database, ops, and QA agents. Use for complex functionality that benefits from parallel domain ownership, isolated context windows, file-based coordination, deterministic locks, explicit handoffs, and Lead-controlled integration.
---

# Team Agentic: Worldwide Org Maintainers

## Mission

Run complex engineering work as a coordinated specialist team rather than one overloaded agent. Preserve each agent's narrow context while maintaining one durable shared program state on disk.

The team consists of:

- Lead Integrator;
- UI Leet Engineer;
- Backend Leet Engineer;
- Database Leet Engineer;
- Ops Leet Engineer;
- QA Leet Engineer.

Load `references/TEAM_AGENT_COORDINATION_PROTOCOL.md` and follow it as the coordination contract.

## Prime directive

The Lead owns the outcome. Specialists own bounded implementation slices. The operator should not become the message bus, arbitrator, or project manager.

The Lead answers specialist questions whenever evidence permits, resolves all cross-domain conflicts, controls integration order, and drives the initiative through green CI and final merge.

## Kickoff

The Lead must create `.agent/team/` and establish `CHARTER.md`, `PLAN.md`, `TASKS.md`, `DECISIONS.md`, `RISKS.md`, `CONTRACTS.md`, `INTEGRATION.md`, `QA.md`, and `STATUS.md` before parallel implementation begins.

The charter contains the definitive acceptance criteria and evidence. Specialists do not independently reinterpret the operator request after kickoff.

## Decomposition rules

Split work by stable ownership boundary, not by arbitrary file count. Prefer tasks that can be completed with minimal shared-context dependence.

A good task has:

- one domain owner;
- explicit inputs and outputs;
- known shared contracts;
- narrow code/resource ownership;
- independent validation;
- a concrete handoff consumer.

Avoid splitting a single invariant across multiple agents unless the Lead explicitly establishes the interface first.

## Lock before write

Every specialist must claim an assigned task before editing. The lock must declare owned paths/symbols/resources. Run `tools/team_lock.py validate` before parallel work proceeds.

Overlapping locks are prohibited unless the Lead explicitly records a shared-edit protocol.

## Shared-memory discipline

Agents communicate through `.agent/team/*.md`, lock records, and handoffs. Do not rely on ephemeral conversation history.

Read only the charter, task record, relevant finalized decisions/contracts, dependencies, and the agent's own handoff inputs. Do not load every other agent's context unless needed for a conflict.

## Pace

The Lead keeps specialists unblocked by making decisions quickly from available evidence. Do not serially wait for every specialist when work is independent. Do not parallelize work that shares an unresolved contract.

## Integration

Specialists never merge. They produce handoff-ready work. The Lead integrates through the authorized VCS abstraction, resolves conflicts, runs complete validation, coordinates QA, and performs the eligible merge.

## Finish condition

Do not call the team complete because all specialists reported done. Completion requires accepted handoffs, integrated behavior, green full-suite checks, QA evidence, operational readiness, and no active locks.
